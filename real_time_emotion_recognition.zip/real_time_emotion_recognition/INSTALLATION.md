# 📦 Installation Guide

Complete step-by-step installation instructions for all platforms.

## Prerequisites

- **Python 3.11 or higher** (3.9+ may work but 3.11+ recommended)
- **Webcam** (built-in or USB)
- **4GB RAM minimum** (8GB recommended for DeepFace)
- **Internet connection** (for initial package downloads)

## Platform-Specific Installation

### Windows 10/11

#### Method 1: Automated Setup (Recommended)

```powershell
# 1. Open PowerShell in project directory
cd C:\path\to\real_time_emotion_recognition

# 2. Run setup script
.\setup.ps1

# 3. Done! Now run:
streamlit run app.py
```

#### Method 2: Manual Setup

```powershell
# 1. Check Python version
python --version
# Should be 3.11 or higher

# 2. Create virtual environment
python -m venv .venv

# 3. Activate virtual environment
.venv\Scripts\Activate.ps1

# 4. Upgrade pip
python -m pip install --upgrade pip

# 5. Install dependencies
pip install -r requirements.txt

# 6. Verify installation
python test_setup.py

# 7. Run application
streamlit run app.py
```

**Troubleshooting Windows:**

If you get "scripts disabled" error:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

If webcam doesn't work:
1. Settings → Privacy → Camera
2. Enable "Allow apps to access your camera"
3. Ensure terminal/Python is allowed

### macOS

```bash
# 1. Check Python version
python3 --version
# Should be 3.11 or higher

# 2. Create virtual environment
python3 -m venv .venv

# 3. Activate virtual environment
source .venv/bin/activate

# 4. Upgrade pip
pip install --upgrade pip

# 5. Install dependencies
pip install -r requirements.txt

# 6. Verify installation
python test_setup.py

# 7. Run application
streamlit run app.py
```

**Troubleshooting macOS:**

Camera permission:
1. System Preferences → Security & Privacy → Camera
2. Grant Terminal/iTerm2 camera access
3. Restart terminal

If OpenCV issues:
```bash
brew install opencv
pip install opencv-python --force-reinstall
```

### Linux (Ubuntu/Debian)

```bash
# 1. Install system dependencies
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv
sudo apt-get install -y libgl1-mesa-glx libglib2.0-0

# 2. Create virtual environment
python3 -m venv .venv

# 3. Activate virtual environment
source .venv/bin/activate

# 4. Upgrade pip
pip install --upgrade pip

# 5. Install dependencies
pip install -r requirements.txt

# 6. Grant camera access
sudo usermod -a -G video $USER
# Logout and login for this to take effect

# 7. Verify installation
python test_setup.py

# 8. Run application
streamlit run app.py
```

**Troubleshooting Linux:**

Check camera devices:
```bash
ls -l /dev/video*
```

If permission denied:
```bash
sudo chmod 666 /dev/video0
```

### Docker Installation

```bash
# 1. Build image
docker build -t emotion-recognition:latest .

# 2. Run container (Linux)
docker run -p 8501:8501 --device=/dev/video0 emotion-recognition:latest

# 3. Access UI
# Open browser to http://localhost:8501
```

**Note:** Docker camera passthrough varies by platform. Linux works best.

## Dependency Installation Details

### Core Dependencies (Required)

```bash
pip install opencv-python>=4.8.0
pip install numpy>=1.24.0
pip install scipy>=1.10.0
pip install fer>=22.4.0
pip install tensorflow>=2.13.0
pip install streamlit>=1.28.0
pip install pandas>=2.0.0
pip install Pillow>=10.0.0
pip install PyYAML>=6.0
```

### Optional Dependencies

```bash
# DeepFace backend (optional, large download ~2GB)
pip install deepface>=0.0.79

# MTCNN face detector (optional, better accuracy)
pip install mtcnn

# Development tools
pip install pytest pytest-cov
pip install black isort flake8
pip install pre-commit
```

## Verification Steps

### 1. Test Installation

```bash
python test_setup.py
```

Expected output:
```
✅ Package Installation
✅ Project Modules
✅ Configuration
✅ Camera Access
```

### 2. Run Unit Tests

```bash
pytest tests/ -v
```

Expected: All tests passing

### 3. Test CLI Mode

```bash
python main.py --fps --draw-box
```

Press 'q' to quit. Should show webcam with emotion detection.

### 4. Test Streamlit UI

```bash
streamlit run app.py
```

Browser should open to http://localhost:8501

## Common Issues & Solutions

### Issue: Python version too old

```bash
# Check version
python --version

# Solution: Install Python 3.11+
# Windows: Download from python.org
# Mac: brew install python@3.11
# Linux: sudo apt-get install python3.11
```

### Issue: pip install fails

```bash
# Try upgrading pip
python -m pip install --upgrade pip

# Try installing individually
pip install opencv-python
pip install fer
pip install streamlit
```

### Issue: OpenCV import error

```bash
# Uninstall all OpenCV packages
pip uninstall opencv-python opencv-python-headless opencv-contrib-python

# Reinstall
pip install opencv-python
```

### Issue: TensorFlow errors

```bash
# For Windows/Mac with Apple Silicon
pip install tensorflow-cpu

# For older systems
pip install tensorflow==2.13.0
```

### Issue: Camera not detected

**Test camera:**
```python
import cv2
cap = cv2.VideoCapture(0)
print(cap.isOpened())  # Should be True
```

**Try different indices:**
```bash
python main.py --camera 1
python main.py --camera 2
```

### Issue: Streamlit won't start

```bash
# Check if port is in use
netstat -ano | findstr :8501  # Windows
lsof -i :8501                 # Mac/Linux

# Use different port
streamlit run app.py --server.port 8502
```

### Issue: DeepFace model download fails

```bash
# Pre-download models
python -c "from deepface import DeepFace; DeepFace.build_model('Emotion')"

# Or use FER backend instead
python main.py --backend fer
```

## Performance Optimization

### For Low-End Hardware

Edit `config.yaml`:
```yaml
camera:
  resize_height: 480      # Lower resolution

performance:
  enabled: true           # Enable performance mode
  frame_skip: 3           # Skip more frames

detector:
  backend: "fer"          # Use faster backend
  mtcnn: false            # Disable MTCNN
```

### For High-End Hardware

```yaml
camera:
  resize_height: 1080     # Higher resolution

performance:
  enabled: false          # Disable frame skipping

detector:
  backend: "deepface"     # Use accurate backend
```

## Development Setup

### Install Development Tools

```bash
# Install all development dependencies
pip install -r requirements.txt

# Install pre-commit hooks
pre-commit install

# Run linters
make lint

# Format code
make format

# Run tests with coverage
make test
```

### IDE Setup

**VS Code:**
```json
{
  "python.linting.enabled": true,
  "python.linting.flake8Enabled": true,
  "python.formatting.provider": "black",
  "editor.formatOnSave": true
}
```

**PyCharm:**
1. Settings → Tools → Black
2. Enable "Format on save"
3. Configure interpreter to use `.venv`

## Uninstallation

```bash
# Deactivate virtual environment
deactivate

# Remove virtual environment
rm -rf .venv  # Mac/Linux
rmdir /s .venv  # Windows

# Remove generated files
rm -rf logs/* shots/* exports/*
rm -rf __pycache__ .pytest_cache
```

## Next Steps

After successful installation:

1. ✅ Read [QUICKSTART.md](QUICKSTART.md) for usage guide
2. ✅ Run `streamlit run app.py` to explore UI
3. ✅ Try `python main.py --help` for CLI options
4. ✅ Check [API.md](API.md) for developer docs
5. ✅ Customize `config.yaml` for your needs

## Getting Help

If you encounter issues:

1. Run `python test_setup.py` to diagnose
2. Check error messages carefully
3. Review [README.md](README.md) troubleshooting section
4. Ensure Python 3.11+ is installed
5. Try reinstalling in fresh virtual environment

## System Requirements Summary

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Python | 3.9 | 3.11+ |
| RAM | 4GB | 8GB |
| CPU | Dual-core | Quad-core+ |
| GPU | None | NVIDIA (for DeepFace) |
| Webcam | 480p | 720p+ |
| Storage | 1GB | 5GB (with DeepFace) |

---

**Ready to install?** Start with `.\setup.ps1` (Windows) or follow manual steps above!
