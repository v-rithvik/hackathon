# 📚 API Documentation

Developer guide for extending and integrating the emotion recognition system.

## Core Modules

### detector.py - Emotion Detection Backend

#### EmotionDetector (Abstract Base Class)

```python
from detector import EmotionDetector

class EmotionDetector(ABC):
    @abstractmethod
    def detect_emotions(self, frame: np.ndarray) -> List[Dict]:
        """
        Detect emotions in RGB frame
        
        Args:
            frame: RGB image as numpy array
            
        Returns:
            List of detections:
            [
                {
                    'box': (x, y, w, h),
                    'emotions': {
                        'happy': 0.8,
                        'sad': 0.1,
                        ...
                    }
                }
            ]
        """
        pass
```

#### Factory Function

```python
from detector import create_detector

# Create FER detector
detector = create_detector("fer", mtcnn=False)

# Create DeepFace detector
detector = create_detector("deepface", model_name="Emotion")

# Use detector
frame = cv2.imread("image.jpg")
rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
results = detector.detect_emotions(rgb)
```

### tracker.py - Multi-Face Tracking

#### CentroidTracker

```python
from tracker import CentroidTracker

tracker = CentroidTracker(
    max_disappeared=30,    # Frames before losing track
    max_distance=50        # Max pixel distance for matching
)

# Update with face boxes
boxes = [(x, y, w, h), ...]
tracked = tracker.update(boxes)  # Returns {face_id: box}

# Get active faces
active_faces = tracker.get_active_faces()
```

#### FaceTracker (High-Level)

```python
from tracker import FaceTracker

tracker = FaceTracker(
    max_disappeared=30,
    max_distance=50,
    smoothing_alpha=0.3,
    debounce_frames=5
)

# Update with detections
detections = [
    {
        'box': (x, y, w, h),
        'emotions': {'happy': 0.8, ...}
    }
]

tracked = tracker.update(detections)
# Returns:
# {
#     face_id: {
#         'box': (x, y, w, h),
#         'emotions': {...},       # Smoothed scores
#         'top_emotion': 'happy',  # Debounced
#         'confidence': 0.8
#     }
# }
```

### utils.py - Utilities

#### ExponentialMovingAverage

```python
from utils import ExponentialMovingAverage

ema = ExponentialMovingAverage(alpha=0.3)

# Update with new scores
scores = {'happy': 0.9, 'sad': 0.1}
smoothed = ema.update(scores)
```

#### EmotionDebouncer

```python
from utils import EmotionDebouncer

debouncer = EmotionDebouncer(debounce_frames=5)

# Update with top emotion
for emotion in stream:
    stable = debouncer.update(emotion)
    # Only changes after 5 consecutive frames
```

#### EmotionLogger

```python
from utils import EmotionLogger

logger = EmotionLogger(log_dir="logs", include_fps=True)

# Start logging
log_file = logger.start_logging()

# Log frames
logger.log_frame(
    face_id=1,
    top_emotion="happy",
    scores={'happy': 0.8, ...},
    fps=30.0
)

# Stop logging
logger.stop_logging()
```

#### SessionStats

```python
from utils import SessionStats

stats = SessionStats()

# Update with each frame
stats.update(face_id=1, emotion="happy", fps=30.0)

# Get summary
summary = stats.get_summary()
# Returns dict with session, emotions, fps, per_face stats

# Export to JSON
filename = stats.export_json(export_dir="exports")
```

#### Helper Functions

```python
from utils import (
    save_screenshot,
    blur_background,
    draw_emotion_text,
    play_alert_sound,
    calculate_fps,
    get_emotion_color,
    EMOTION_EMOJIS,
    EMOTIONS
)

# Screenshot
filename = save_screenshot(
    frame,
    directory="shots",
    mask_faces=False,
    face_boxes=[(x, y, w, h)]
)

# Blur background
blurred = blur_background(frame, face_boxes)

# Draw text with background
frame = draw_emotion_text(
    frame,
    text="Happy",
    position=(10, 30),
    font_scale=0.9,
    thickness=2
)

# Alert sound
play_alert_sound()

# FPS calculation
fps, current_time = calculate_fps(
    prev_time=last_time,
    current_time=time.time(),
    smooth_fps=30.0,
    alpha=0.1
)

# Emotion color (BGR)
color = get_emotion_color("happy")  # Returns (B, G, R) tuple

# Constants
print(EMOTIONS)  # ['angry', 'disgust', ...]
print(EMOTION_EMOJIS['happy'])  # '😊'
```

## Integration Examples

### Custom Detector

```python
from detector import EmotionDetector

class MyCustomDetector(EmotionDetector):
    def __init__(self, model_path):
        self.model = load_model(model_path)
    
    def detect_emotions(self, frame):
        # Your detection logic
        results = self.model.predict(frame)
        
        # Format as required
        return [
            {
                'box': (x, y, w, h),
                'emotions': {
                    'happy': score1,
                    'sad': score2,
                    # ... all 7 emotions
                }
            }
        ]
    
    def get_backend_name(self):
        return "MyCustomDetector"

# Use it
detector = MyCustomDetector("model.h5")
```

### Flask API

```python
from flask import Flask, request, jsonify
import cv2
import numpy as np
from detector import create_detector

app = Flask(__name__)
detector = create_detector("fer")

@app.route('/analyze', methods=['POST'])
def analyze():
    # Get image from request
    file = request.files['image']
    npimg = np.frombuffer(file.read(), np.uint8)
    frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Detect emotions
    results = detector.detect_emotions(rgb)
    
    return jsonify({
        'faces': len(results),
        'detections': results
    })

if __name__ == '__main__':
    app.run(port=5000)
```

### Video File Processing

```python
import cv2
from detector import create_detector
from tracker import FaceTracker
from utils import SessionStats

detector = create_detector("fer")
tracker = FaceTracker()
stats = SessionStats()

cap = cv2.VideoCapture("video.mp4")

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Process
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    detections = detector.detect_emotions(rgb)
    tracked = tracker.update(detections)
    
    # Update stats
    for face_id, data in tracked.items():
        stats.update(face_id, data['top_emotion'])

cap.release()

# Export results
stats.export_json("exports")
```

### Real-time Streaming

```python
import cv2
from detector import create_detector
from tracker import FaceTracker

detector = create_detector("fer")
tracker = FaceTracker(smoothing_alpha=0.3, debounce_frames=5)

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Detect
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    detections = detector.detect_emotions(rgb)
    
    # Track
    tracked = tracker.update(detections)
    
    # Draw results
    for face_id, data in tracked.items():
        x, y, w, h = data['box']
        emotion = data['top_emotion']
        confidence = data['confidence']
        
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        label = f"#{face_id}: {emotion} ({confidence:.2f})"
        cv2.putText(frame, label, (x, y-10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    cv2.imshow("Emotions", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
```

### Batch Image Processing

```python
from pathlib import Path
import cv2
from detector import create_detector
import json

detector = create_detector("fer")
results = {}

for image_path in Path("images/").glob("*.jpg"):
    frame = cv2.imread(str(image_path))
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    detections = detector.detect_emotions(rgb)
    
    results[image_path.name] = {
        'num_faces': len(detections),
        'emotions': [
            {
                'top': max(d['emotions'], key=d['emotions'].get),
                'scores': d['emotions']
            }
            for d in detections
        ]
    }

with open('batch_results.json', 'w') as f:
    json.dump(results, f, indent=2)
```

## Configuration

### Loading Config

```python
import yaml

with open('config.yaml', 'r') as f:
    config = yaml.safe_load(f)

camera_index = config['camera']['index']
backend = config['detector']['backend']
```

### Creating Custom Config

```python
config = {
    'camera': {'index': 0, 'resize_height': 720},
    'detector': {'backend': 'fer', 'mtcnn': False},
    'smoothing': {'enabled': True, 'alpha': 0.3},
    'tracking': {'max_disappeared': 30},
    'performance': {'enabled': False, 'frame_skip': 1}
}

with open('custom_config.yaml', 'w') as f:
    yaml.dump(config, f)
```

## Testing

### Unit Tests

```python
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_tracker.py -v

# Run with coverage
pytest tests/ --cov=. --cov-report=html
```

### Custom Test

```python
from tracker import CentroidTracker

def test_custom_tracking():
    tracker = CentroidTracker(max_disappeared=5)
    
    # Frame 1
    boxes1 = [(50, 50, 100, 100)]
    result1 = tracker.update(boxes1)
    face_id = list(result1.keys())[0]
    
    # Frame 2 - moved slightly
    boxes2 = [(55, 55, 100, 100)]
    result2 = tracker.update(boxes2)
    
    # Should maintain ID
    assert face_id in result2
    assert len(result2) == 1
```

## Performance Optimization

### Frame Skipping

```python
frame_counter = 0
frame_skip = 3
last_detections = []

while True:
    ret, frame = cap.read()
    frame_counter += 1
    
    if frame_counter >= frame_skip:
        # Process frame
        detections = detector.detect_emotions(rgb)
        last_detections = detections
        frame_counter = 0
    else:
        # Reuse last detections
        detections = last_detections
```

### Resolution Scaling

```python
# Process at lower resolution
scale = 0.5
small_frame = cv2.resize(frame, None, fx=scale, fy=scale)
detections = detector.detect_emotions(small_frame)

# Scale boxes back up
for detection in detections:
    x, y, w, h = detection['box']
    detection['box'] = (
        int(x / scale),
        int(y / scale),
        int(w / scale),
        int(h / scale)
    )
```

## Error Handling

```python
import cv2
from detector import create_detector

try:
    detector = create_detector("fer")
except ImportError as e:
    print(f"FER not installed: {e}")
    detector = create_detector("dummy")

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to read frame")
            break
        
        try:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            detections = detector.detect_emotions(rgb)
        except Exception as e:
            print(f"Detection error: {e}")
            continue
            
except KeyboardInterrupt:
    print("Stopped by user")
finally:
    cap.release()
    cv2.destroyAllWindows()
```

## Constants

```python
# Emotions
EMOTIONS = ["angry", "disgust", "fear", "happy", "sad", "surprise", "neutral"]

# Emoji mappings
EMOTION_EMOJIS = {
    "angry": "😠",
    "disgust": "🤢",
    "fear": "😨",
    "happy": "😊",
    "sad": "😢",
    "surprise": "😲",
    "neutral": "😐"
}
```

## Type Hints

```python
from typing import Dict, List, Tuple
import numpy as np

def process_emotions(
    frame: np.ndarray,
    detector: EmotionDetector,
    tracker: FaceTracker
) -> Dict[int, Dict]:
    """
    Process frame and return tracked emotions
    
    Args:
        frame: RGB image array
        detector: Emotion detector instance
        tracker: Face tracker instance
        
    Returns:
        Dictionary mapping face_id to emotion data
    """
    detections = detector.detect_emotions(frame)
    tracked = tracker.update(detections)
    return tracked
```

---

For more examples, see the `app.py` and `main.py` source files.
