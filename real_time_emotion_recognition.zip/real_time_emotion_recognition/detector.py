"""
Emotion detection backend abstraction layer
Supports multiple backends: FER, DeepFace
"""

from abc import ABC, abstractmethod
from typing import Dict, List

import cv2
import numpy as np


class EmotionDetector(ABC):
    """Abstract base class for emotion detectors"""
    
    @abstractmethod
    def detect_emotions(self, frame: np.ndarray) -> List[Dict]:
        """
        Detect emotions in a frame
        
        Args:
            frame: RGB image frame
            
        Returns:
            List of dicts with 'box': (x, y, w, h) and 'emotions': {emotion: score}
        """
        pass
    
    @abstractmethod
    def get_backend_name(self) -> str:
        """Get backend name"""
        pass


class FERDetector(EmotionDetector):
    """FER (Facial Expression Recognition) backend"""
    
    def __init__(self, mtcnn: bool = False):
        """
        Args:
            mtcnn: Use MTCNN face detector (slower but better)
        """
        try:
            from fer import FER
        except ImportError:
            raise ImportError("FER not installed. Run: pip install fer")
        
        self.detector = FER(mtcnn=mtcnn)
        self.mtcnn = mtcnn
        
    def detect_emotions(self, frame: np.ndarray) -> List[Dict]:
        """Detect emotions using FER"""
        # FER expects RGB
        if len(frame.shape) == 2:
            frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
        elif frame.shape[2] == 4:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2RGB)
        
        results = self.detector.detect_emotions(frame)
        
        # Normalize format
        normalized = []
        for result in results:
            if 'box' in result and 'emotions' in result:
                # FER returns box as [x, y, w, h]
                box = result['box']
                # Ensure box is tuple of ints
                box = tuple(int(v) for v in box)
                
                normalized.append({
                    'box': box,
                    'emotions': result['emotions']
                })
        
        return normalized
    
    def get_backend_name(self) -> str:
        return f"FER (mtcnn={self.mtcnn})"


class DeepFaceDetector(EmotionDetector):
    """DeepFace backend"""
    
    def __init__(self, model_name: str = "Emotion"):
        """
        Args:
            model_name: DeepFace model name
        """
        try:
            from deepface import DeepFace
        except ImportError:
            raise ImportError("DeepFace not installed. Run: pip install deepface")
        
        self.DeepFace = DeepFace
        self.model_name = model_name
        
        # DeepFace emotion mapping
        self.emotion_map = {
            'angry': 'angry',
            'disgust': 'disgust',
            'fear': 'fear',
            'happy': 'happy',
            'sad': 'sad',
            'surprise': 'surprise',
            'neutral': 'neutral'
        }
        
    def detect_emotions(self, frame: np.ndarray) -> List[Dict]:
        """Detect emotions using DeepFace"""
        try:
            # DeepFace expects BGR (OpenCV format)
            if len(frame.shape) == 2:
                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
            elif frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # DeepFace analyze
            results = self.DeepFace.analyze(
                frame,
                actions=['emotion'],
                enforce_detection=False,
                detector_backend='opencv',
                silent=True
            )
            
            # Handle both single face and multiple faces
            if not isinstance(results, list):
                results = [results]
            
            normalized = []
            for result in results:
                # Extract face region
                region = result.get('region', {})
                x = region.get('x', 0)
                y = region.get('y', 0)
                w = region.get('w', 100)
                h = region.get('h', 100)
                
                # Get emotion scores
                emotions_raw = result.get('emotion', {})
                
                # Normalize emotion scores (DeepFace gives percentages)
                emotions = {}
                for key, value in emotions_raw.items():
                    emotion_key = key.lower()
                    if emotion_key in self.emotion_map:
                        emotions[self.emotion_map[emotion_key]] = value / 100.0
                
                # Ensure all emotions present
                for emotion in ['angry', 'disgust', 'fear', 'happy', 'sad', 'surprise', 'neutral']:
                    if emotion not in emotions:
                        emotions[emotion] = 0.0
                
                normalized.append({
                    'box': (int(x), int(y), int(w), int(h)),
                    'emotions': emotions
                })
            
            return normalized
            
        except Exception as e:
            # If detection fails, return empty
            print(f"DeepFace detection error: {e}")
            return []
    
    def get_backend_name(self) -> str:
        return f"DeepFace ({self.model_name})"


class DummyDetector(EmotionDetector):
    """Dummy detector for testing"""
    
    def detect_emotions(self, frame: np.ndarray) -> List[Dict]:
        """Return dummy detection"""
        h, w = frame.shape[:2]
        return [{
            'box': (w//4, h//4, w//2, h//2),
            'emotions': {
                'neutral': 0.7,
                'happy': 0.2,
                'sad': 0.05,
                'angry': 0.03,
                'surprise': 0.01,
                'fear': 0.005,
                'disgust': 0.005
            }
        }]
    
    def get_backend_name(self) -> str:
        return "Dummy (Testing)"


def create_detector(backend: str = "fer", **kwargs) -> EmotionDetector:
    """
    Factory function to create emotion detector
    
    Args:
        backend: Backend name ("fer" or "deepface")
        **kwargs: Backend-specific arguments
        
    Returns:
        EmotionDetector instance
    """
    backend = backend.lower()
    
    if backend == "fer":
        mtcnn = kwargs.get('mtcnn', False)
        return FERDetector(mtcnn=mtcnn)
    elif backend == "deepface":
        model_name = kwargs.get('model_name', 'Emotion')
        return DeepFaceDetector(model_name=model_name)
    elif backend == "dummy":
        return DummyDetector()
    else:
        raise ValueError(f"Unknown backend: {backend}. Use 'fer' or 'deepface'")
