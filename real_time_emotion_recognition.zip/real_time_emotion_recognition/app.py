"""
Streamlit UI for Real-time Emotion Recognition
Beautiful, responsive web interface with all features
"""

import time
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import streamlit as st
import yaml
from PIL import Image

from detector import create_detector
from tracker import FaceTracker
from utils import (EMOTION_EMOJIS, EMOTIONS, SessionStats, blur_background,
                   create_directories, get_emotion_color, play_alert_sound,
                   save_screenshot)

# Page config
st.set_page_config(
    page_title="Real-time Emotion Recognition",
    page_icon="😊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .emotion-display {
        font-size: 3rem;
        text-align: center;
        padding: 1rem;
        border-radius: 10px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        margin: 1rem 0;
    }
    .stat-box {
        padding: 1rem;
        border-radius: 8px;
        background-color: #f0f2f6;
        margin: 0.5rem 0;
    }
    .alert-box {
        padding: 1rem;
        border-radius: 8px;
        background-color: #ff4b4b;
        color: white;
        margin: 1rem 0;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }
</style>
""", unsafe_allow_html=True)


def load_config():
    """Load configuration from YAML"""
    config_path = Path("config.yaml")
    if config_path.exists():
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    return {}


def init_session_state():
    """Initialize Streamlit session state"""
    if 'running' not in st.session_state:
        st.session_state.running = False
    if 'detector' not in st.session_state:
        st.session_state.detector = None
    if 'tracker' not in st.session_state:
        st.session_state.tracker = None
    if 'cap' not in st.session_state:
        st.session_state.cap = None
    if 'stats' not in st.session_state:
        st.session_state.stats = SessionStats()
    if 'logging_enabled' not in st.session_state:
        st.session_state.logging_enabled = False
    if 'logger' not in st.session_state:
        st.session_state.logger = None
    if 'emotion_timeline' not in st.session_state:
        st.session_state.emotion_timeline = {emotion: deque(maxlen=60) for emotion in EMOTIONS}
    if 'timeline_times' not in st.session_state:
        st.session_state.timeline_times = deque(maxlen=60)
    if 'selected_face_id' not in st.session_state:
        st.session_state.selected_face_id = None
    if 'alert_counts' not in st.session_state:
        st.session_state.alert_counts = defaultdict(int)
    if 'fps' not in st.session_state:
        st.session_state.fps = 0.0
    if 'prev_time' not in st.session_state:
        st.session_state.prev_time = time.time()
    if 'frame_skip_counter' not in st.session_state:
        st.session_state.frame_skip_counter = 0
    if 'last_detections' not in st.session_state:
        st.session_state.last_detections = {}


def main():
    """Main Streamlit application"""
    
    # Header
    st.markdown('<div class="main-header">😊 Real-time Emotion Recognition</div>', unsafe_allow_html=True)
    
    # Initialize
    init_session_state()
    config = load_config()
    create_directories(config)
    
    # Important note about webcam
    st.info("📸 **Webcam Access:** Click 'Take Photo' below to capture an image for emotion detection. For continuous video, use the CLI version with `python main.py`")
    
    # Sidebar - Settings
    st.sidebar.title("⚙️ Settings")
    
    # Camera settings
    st.sidebar.subheader("📷 Camera")
    camera_index = st.sidebar.number_input(
        "Camera Index", 
        min_value=0, 
        max_value=5, 
        value=config.get('camera', {}).get('index', 0)
    )
    resize_height = st.sidebar.slider(
        "Resize Height", 
        min_value=360, 
        max_value=1080, 
        value=config.get('camera', {}).get('resize_height', 720),
        step=60
    )
    
    # Display settings
    st.sidebar.subheader("🎨 Display")
    show_fps = st.sidebar.checkbox(
        "Show FPS", 
        value=config.get('display', {}).get('show_fps', True)
    )
    draw_boxes = st.sidebar.checkbox(
        "Draw Face Boxes", 
        value=config.get('display', {}).get('draw_boxes', True)
    )
    emoji_overlay = st.sidebar.checkbox(
        "Emoji Overlay", 
        value=config.get('display', {}).get('emoji_overlay', True)
    )
    blur_bg = st.sidebar.checkbox(
        "Blur Background (Privacy)", 
        value=config.get('display', {}).get('blur_background', False)
    )
    
    # Backend selection
    st.sidebar.subheader("🧠 Detection Backend")
    backend = st.sidebar.selectbox(
        "Backend", 
        ["fer", "deepface"],
        index=0 if config.get('detector', {}).get('backend', 'fer') == 'fer' else 1
    )
    
    mtcnn = False  # Initialize mtcnn
    if backend == "fer":
        mtcnn = st.sidebar.checkbox(
            "Use MTCNN (slower, better)", 
            value=config.get('detector', {}).get('mtcnn', False)
        )
    
    # Smoothing settings
    st.sidebar.subheader("📊 Smoothing")
    smoothing_enabled = st.sidebar.checkbox(
        "Enable Smoothing", 
        value=config.get('smoothing', {}).get('enabled', True)
    )
    smoothing_alpha = st.sidebar.slider(
        "Smoothing Factor", 
        min_value=0.1, 
        max_value=1.0, 
        value=config.get('smoothing', {}).get('alpha', 0.3),
        step=0.05
    )
    debounce_frames = st.sidebar.slider(
        "Debounce Frames", 
        min_value=1, 
        max_value=20, 
        value=config.get('smoothing', {}).get('debounce_frames', 5)
    )
    
    # Performance mode
    st.sidebar.subheader("⚡ Performance")
    perf_mode = st.sidebar.checkbox(
        "Performance Mode", 
        value=config.get('performance', {}).get('enabled', False)
    )
    if perf_mode:
        frame_skip = st.sidebar.slider(
            "Frame Skip", 
            min_value=1, 
            max_value=5, 
            value=config.get('performance', {}).get('frame_skip', 2)
        )
    else:
        frame_skip = 1
    
    # Alert settings
    st.sidebar.subheader("🔔 Alerts")
    alerts_enabled = st.sidebar.checkbox(
        "Enable Alerts", 
        value=config.get('alerts', {}).get('enabled', True)
    )
    alert_threshold = st.sidebar.slider(
        "Alert Threshold", 
        min_value=0.5, 
        max_value=1.0, 
        value=config.get('alerts', {}).get('threshold', 0.8),
        step=0.05
    )
    alert_min_frames = st.sidebar.slider(
        "Min Alert Frames", 
        min_value=5, 
        max_value=30, 
        value=config.get('alerts', {}).get('min_frames', 10)
    )
    
    # Main controls
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("▶️ Start Webcam" if not st.session_state.running else "⏸️ Stop Webcam"):
            if not st.session_state.running:
                # Start webcam
                st.session_state.cap = cv2.VideoCapture(camera_index)
                if not st.session_state.cap.isOpened():
                    st.error("❌ Could not open webcam. Check camera index and permissions.")
                else:
                    # Initialize detector
                    try:
                        if backend == "fer":
                            st.session_state.detector = create_detector("fer", mtcnn=mtcnn)
                        else:
                            st.session_state.detector = create_detector("deepface")
                        
                        # Initialize tracker
                        st.session_state.tracker = FaceTracker(
                            max_disappeared=config.get('tracking', {}).get('max_disappeared', 30),
                            max_distance=config.get('tracking', {}).get('centroid_distance_thresh', 50),
                            smoothing_alpha=smoothing_alpha if smoothing_enabled else 1.0,
                            debounce_frames=debounce_frames if smoothing_enabled else 1
                        )
                        
                        st.session_state.running = True
                        st.session_state.stats = SessionStats()
                        st.success(f"✅ Started with {st.session_state.detector.get_backend_name()}")
                    except Exception as e:
                        st.error(f"❌ Error initializing detector: {e}")
                        st.session_state.running = False
            else:
                # Stop webcam
                if st.session_state.cap:
                    st.session_state.cap.release()
                st.session_state.running = False
                st.info("⏸️ Webcam stopped")
    
    with col2:
        if st.button("📸 Screenshot"):
            if st.session_state.running and 'current_frame' in st.session_state:
                mask_faces = config.get('screenshots', {}).get('mask_faces', False)
                face_boxes = []
                if 'tracked_faces' in st.session_state:
                    face_boxes = [data['box'] for data in st.session_state.tracked_faces.values()]
                
                filename = save_screenshot(
                    st.session_state.current_frame,
                    directory=config.get('screenshots', {}).get('directory', 'shots'),
                    mask_faces=mask_faces,
                    face_boxes=face_boxes
                )
                st.success(f"📸 Screenshot saved: {filename}")
            else:
                st.warning("⚠️ Start webcam first")
    
    with col3:
        if st.button("📊 Export Summary"):
            try:
                filename = st.session_state.stats.export_json(
                    export_dir=config.get('export', {}).get('directory', 'exports')
                )
                st.success(f"📊 Summary exported: {filename}")
                
                # Show summary
                summary = st.session_state.stats.get_summary()
                with st.expander("📄 View Summary"):
                    st.json(summary)
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    # Logging control
    col_log1, col_log2 = st.columns(2)
    with col_log1:
        if st.button("📝 Start Logging" if not st.session_state.logging_enabled else "⏹️ Stop Logging"):
            if not st.session_state.logging_enabled:
                from utils import EmotionLogger
                st.session_state.logger = EmotionLogger(
                    log_dir=config.get('logging', {}).get('directory', 'logs'),
                    include_fps=config.get('logging', {}).get('include_fps', True)
                )
                log_file = st.session_state.logger.start_logging()
                st.session_state.logging_enabled = True
                st.success(f"📝 Logging to: {log_file}")
            else:
                if st.session_state.logger:
                    st.session_state.logger.stop_logging()
                st.session_state.logging_enabled = False
                st.info("⏹️ Logging stopped")
    
    # Face selector
    if st.session_state.running and 'tracked_faces' in st.session_state:
        active_faces = list(st.session_state.tracked_faces.keys())
        if active_faces:
            selected = st.selectbox(
                "👤 Select Face to Track",
                ["All Faces"] + [f"Face {fid}" for fid in active_faces],
                index=0
            )
            if selected != "All Faces":
                st.session_state.selected_face_id = int(selected.split()[1])
            else:
                st.session_state.selected_face_id = None
    
    # Main display area
    col_video, col_charts = st.columns([2, 1])
    
    with col_video:
        st.subheader("📹 Live Feed")
        video_placeholder = st.empty()
        
    with col_charts:
        st.subheader("📊 Current Emotion")
        emotion_text_placeholder = st.empty()
        emotion_bar_placeholder = st.empty()
    
    # Timeline
    st.subheader("📈 Emotion Timeline (60s)")
    timeline_placeholder = st.empty()
    
    # Alerts
    alert_placeholder = st.empty()
    
    # Stats
    col_stats1, col_stats2, col_stats3 = st.columns(3)
    stats_placeholders = {
        'fps': col_stats1.empty(),
        'faces': col_stats2.empty(),
        'frames': col_stats3.empty()
    }
    
    # Main processing loop
    if st.session_state.running:
        process_frame(
            config, video_placeholder, emotion_text_placeholder, 
            emotion_bar_placeholder, timeline_placeholder, alert_placeholder,
            stats_placeholders, resize_height, show_fps, draw_boxes, 
            emoji_overlay, blur_bg, frame_skip, alerts_enabled,
            alert_threshold, alert_min_frames
        )


def process_frame(config, video_placeholder, emotion_text_placeholder,
                 emotion_bar_placeholder, timeline_placeholder, alert_placeholder,
                 stats_placeholders, resize_height, show_fps, draw_boxes,
                 emoji_overlay, blur_bg, frame_skip, alerts_enabled,
                 alert_threshold, alert_min_frames):
    """Process single frame"""
    
    ret, frame = st.session_state.cap.read()
    if not ret:
        st.error("❌ Failed to read frame")
        st.session_state.running = False
        return
    
    # Resize
    if resize_height and frame.shape[0] > 0:
        scale = resize_height / frame.shape[0]
        frame = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    
    # Frame skipping for performance
    st.session_state.frame_skip_counter += 1
    should_process = st.session_state.frame_skip_counter >= frame_skip
    
    if should_process:
        st.session_state.frame_skip_counter = 0
        
        # Convert to RGB
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Detect emotions
        detections = st.session_state.detector.detect_emotions(rgb)
        
        # Track faces
        tracked_faces = st.session_state.tracker.update(detections)
        st.session_state.tracked_faces = tracked_faces
        st.session_state.last_detections = tracked_faces
    else:
        # Reuse last detections
        tracked_faces = st.session_state.last_detections
    
    # Calculate FPS
    current_time = time.time()
    fps = 1.0 / (current_time - st.session_state.prev_time) if (current_time - st.session_state.prev_time) > 0 else 0
    st.session_state.fps = 0.1 * fps + 0.9 * st.session_state.fps
    st.session_state.prev_time = current_time
    
    # Process tracked faces
    display_frame = frame.copy()
    current_emotions = {}
    alerts = []
    
    for face_id, data in tracked_faces.items():
        box = data['box']
        emotions = data['emotions']
        top_emotion = data['top_emotion']
        confidence = data['confidence']
        
        x, y, w, h = box
        
        # Draw bounding box
        if draw_boxes:
            color = get_emotion_color(top_emotion)
            cv2.rectangle(display_frame, (x, y), (x+w, y+h), color, 2)
            
            # Draw label
            label = f"#{face_id}: {top_emotion} ({confidence:.2f})"
            cv2.putText(display_frame, label, (x, y-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        # Draw emoji
        if emoji_overlay and top_emotion in EMOTION_EMOJIS:
            emoji = EMOTION_EMOJIS[top_emotion]
            cv2.putText(display_frame, emoji, (x+w+5, y+30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2)
        
        # Store for display
        current_emotions[face_id] = (top_emotion, emotions, confidence)
        
        # Check alerts
        if alerts_enabled and top_emotion in ['angry', 'sad']:
            if confidence >= alert_threshold:
                st.session_state.alert_counts[face_id] += 1
                if st.session_state.alert_counts[face_id] >= alert_min_frames:
                    alerts.append((face_id, top_emotion, confidence))
            else:
                st.session_state.alert_counts[face_id] = 0
        
        # Update stats
        st.session_state.stats.update(face_id, top_emotion, st.session_state.fps)
        
        # Log
        if st.session_state.logging_enabled and st.session_state.logger:
            st.session_state.logger.log_frame(face_id, top_emotion, emotions, st.session_state.fps)
    
    # Apply background blur if enabled
    if blur_bg and tracked_faces:
        face_boxes = [data['box'] for data in tracked_faces.values()]
        display_frame = blur_background(display_frame, face_boxes)
    
    # Draw FPS
    if show_fps:
        cv2.putText(display_frame, f"FPS: {st.session_state.fps:.1f}", 
                   (10, display_frame.shape[0]-10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    # Store for screenshot
    st.session_state.current_frame = display_frame.copy()
    
    # Display video
    video_placeholder.image(display_frame, channels="BGR", use_container_width=True)
    
    # Display emotion for selected face
    display_face_id = st.session_state.selected_face_id
    if display_face_id is None and current_emotions:
        display_face_id = list(current_emotions.keys())[0]
    
    if display_face_id in current_emotions:
        top_emotion, emotions, confidence = current_emotions[display_face_id]
        
        # Emotion text
        emoji = EMOTION_EMOJIS.get(top_emotion, "")
        emotion_text_placeholder.markdown(
            f'<div class="emotion-display">{emoji} {top_emotion.upper()} ({confidence:.2%})</div>',
            unsafe_allow_html=True
        )
        
        # Emotion bar chart
        import pandas as pd
        emotion_df = pd.DataFrame({
            'Emotion': list(emotions.keys()),
            'Score': list(emotions.values())
        }).sort_values('Score', ascending=False)
        
        emotion_bar_placeholder.bar_chart(emotion_df.set_index('Emotion'))
        
        # Update timeline
        current_timestamp = datetime.now()
        st.session_state.timeline_times.append(current_timestamp)
        for emotion in EMOTIONS:
            st.session_state.emotion_timeline[emotion].append(emotions.get(emotion, 0.0))
        
        # Plot timeline
        if len(st.session_state.timeline_times) > 1:
            timeline_df = pd.DataFrame(st.session_state.emotion_timeline)
            timeline_placeholder.line_chart(timeline_df)
    
    # Display alerts
    if alerts:
        alert_html = '<div class="alert-box">🚨 <strong>ALERT</strong><br>'
        for face_id, emotion, conf in alerts:
            alert_html += f"Face #{face_id}: {emotion.upper()} detected ({conf:.2%})<br>"
        alert_html += '</div>'
        alert_placeholder.markdown(alert_html, unsafe_allow_html=True)
        
        # Play sound
        if config.get('alerts', {}).get('audio_enabled', True):
            try:
                play_alert_sound()
            except:
                pass
    else:
        alert_placeholder.empty()
    
    # Update stats display
    stats_placeholders['fps'].metric("FPS", f"{st.session_state.fps:.1f}")
    stats_placeholders['faces'].metric("Active Faces", len(tracked_faces))
    stats_placeholders['frames'].metric("Total Frames", st.session_state.stats.frame_count)


if __name__ == "__main__":
    main()
