"""
Quick Test Script
Verify installation and basic functionality
"""

import sys


def check_imports():
    """Check if all required packages are installed"""
    print("Checking required packages...")
    
    packages = {
        'cv2': 'opencv-python',
        'numpy': 'numpy',
        'scipy': 'scipy',
        'yaml': 'PyYAML',
        'fer': 'fer',
        'streamlit': 'streamlit',
        'pandas': 'pandas',
        'PIL': 'Pillow'
    }
    
    missing = []
    for module, package in packages.items():
        try:
            __import__(module)
            print(f"  ✓ {package}")
        except ImportError:
            print(f"  ✗ {package} - MISSING")
            missing.append(package)
    
    if missing:
        print(f"\n❌ Missing packages: {', '.join(missing)}")
        print("Run: pip install -r requirements.txt")
        return False
    
    print("\n✅ All required packages installed!")
    return True


def check_modules():
    """Check if project modules can be imported"""
    print("\nChecking project modules...")
    
    modules = ['detector', 'tracker', 'utils']
    
    for module in modules:
        try:
            __import__(module)
            print(f"  ✓ {module}.py")
        except Exception as e:
            print(f"  ✗ {module}.py - ERROR: {e}")
            return False
    
    print("\n✅ All project modules OK!")
    return True


def check_camera():
    """Check if camera is accessible"""
    print("\nChecking camera access...")
    
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("  ⚠ Camera 0 not accessible")
            print("  Try different camera indices with --camera flag")
            return False
        
        ret, frame = cap.read()
        cap.release()
        
        if ret:
            print(f"  ✓ Camera 0 accessible ({frame.shape[1]}x{frame.shape[0]})")
            return True
        else:
            print("  ⚠ Camera opened but cannot read frames")
            return False
            
    except Exception as e:
        print(f"  ✗ Camera check failed: {e}")
        return False


def check_config():
    """Check if config file exists"""
    print("\nChecking configuration...")
    
    import os
    if os.path.exists('config.yaml'):
        print("  ✓ config.yaml found")
        return True
    else:
        print("  ⚠ config.yaml not found")
        return False


def main():
    """Run all checks"""
    print("=" * 50)
    print("Real-time Emotion Recognition - System Check")
    print("=" * 50)
    print()
    
    results = []
    
    results.append(("Package Installation", check_imports()))
    results.append(("Project Modules", check_modules()))
    results.append(("Configuration", check_config()))
    results.append(("Camera Access", check_camera()))
    
    print("\n" + "=" * 50)
    print("Summary")
    print("=" * 50)
    
    for name, status in results:
        symbol = "✅" if status else "⚠️"
        print(f"{symbol} {name}")
    
    all_ok = all(status for _, status in results[:-1])  # Camera is optional
    
    print()
    if all_ok:
        print("🎉 System ready! Try:")
        print("   streamlit run app.py")
        print("   python main.py --fps --draw-box")
    else:
        print("⚠️  Some checks failed. See messages above.")
        print("   Run: pip install -r requirements.txt")
    print()


if __name__ == "__main__":
    main()
