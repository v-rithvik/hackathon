"""
Multi-face tracking with stable ID assignment
Uses centroid-based tracking to maintain face identities across frames
"""

from collections import OrderedDict
from typing import Dict, List, Tuple

import numpy as np
from scipy.spatial import distance as dist


class CentroidTracker:
    """
    Centroid-based object tracker for maintaining face IDs across frames
    """
    
    def __init__(self, max_disappeared: int = 30, max_distance: float = 50):
        """
        Args:
            max_disappeared: Maximum frames a face can disappear before losing ID
            max_distance: Maximum centroid distance to match faces
        """
        self.next_object_id = 0
        self.objects = OrderedDict()  # face_id -> centroid
        self.disappeared = OrderedDict()  # face_id -> frames disappeared
        self.max_disappeared = max_disappeared
        self.max_distance = max_distance
        
    def register(self, centroid: Tuple[float, float]) -> int:
        """Register a new face with unique ID"""
        face_id = self.next_object_id
        self.objects[face_id] = centroid
        self.disappeared[face_id] = 0
        self.next_object_id += 1
        return face_id
        
    def deregister(self, face_id: int):
        """Remove a face ID"""
        del self.objects[face_id]
        del self.disappeared[face_id]
        
    def update(self, face_boxes: List[Tuple[int, int, int, int]]) -> Dict[int, Tuple[int, int, int, int]]:
        """
        Update tracker with new face detections
        
        Args:
            face_boxes: List of (x, y, w, h) face bounding boxes
            
        Returns:
            Dictionary mapping face_id to (x, y, w, h) box
        """
        # If no detections, mark all as disappeared
        if len(face_boxes) == 0:
            for face_id in list(self.disappeared.keys()):
                self.disappeared[face_id] += 1
                
                # Deregister if disappeared too long
                if self.disappeared[face_id] > self.max_disappeared:
                    self.deregister(face_id)
                    
            return {}
        
        # Calculate centroids for input boxes
        input_centroids = np.zeros((len(face_boxes), 2), dtype="float")
        for i, (x, y, w, h) in enumerate(face_boxes):
            cx = x + w / 2.0
            cy = y + h / 2.0
            input_centroids[i] = (cx, cy)
        
        # If no existing objects, register all as new
        if len(self.objects) == 0:
            result = {}
            for i, centroid in enumerate(input_centroids):
                face_id = self.register(centroid)
                result[face_id] = face_boxes[i]
            return result
        
        # Get existing object IDs and centroids
        object_ids = list(self.objects.keys())
        object_centroids = list(self.objects.values())
        
        # Compute distances between existing and new centroids
        D = dist.cdist(np.array(object_centroids), input_centroids)
        
        # Find minimum distance for each existing object
        rows = D.min(axis=1).argsort()
        cols = D.argmin(axis=1)[rows]
        
        used_rows = set()
        used_cols = set()
        result = {}
        
        # Match existing objects to new detections
        for (row, col) in zip(rows, cols):
            if row in used_rows or col in used_cols:
                continue
                
            # Check if distance is within threshold
            if D[row, col] > self.max_distance:
                continue
                
            # Update existing object
            face_id = object_ids[row]
            self.objects[face_id] = input_centroids[col]
            self.disappeared[face_id] = 0
            result[face_id] = face_boxes[col]
            
            used_rows.add(row)
            used_cols.add(col)
        
        # Handle disappeared objects
        unused_rows = set(range(D.shape[0])) - used_rows
        for row in unused_rows:
            face_id = object_ids[row]
            self.disappeared[face_id] += 1
            
            if self.disappeared[face_id] > self.max_disappeared:
                self.deregister(face_id)
        
        # Register new objects
        unused_cols = set(range(D.shape[1])) - used_cols
        for col in unused_cols:
            face_id = self.register(input_centroids[col])
            result[face_id] = face_boxes[col]
        
        return result
    
    def get_active_faces(self) -> List[int]:
        """Get list of currently active face IDs"""
        return list(self.objects.keys())
    
    def reset(self):
        """Reset tracker state"""
        self.next_object_id = 0
        self.objects = OrderedDict()
        self.disappeared = OrderedDict()


class FaceTracker:
    """
    High-level face tracker with per-face emotion smoothing
    """
    
    def __init__(self, max_disappeared: int = 30, max_distance: float = 50,
                 smoothing_alpha: float = 0.3, debounce_frames: int = 5):
        """
        Args:
            max_disappeared: Max frames before losing track
            max_distance: Max centroid distance for matching
            smoothing_alpha: EMA smoothing factor
            debounce_frames: Frames needed for emotion change
        """
        from utils import ExponentialMovingAverage, EmotionDebouncer
        
        self.centroid_tracker = CentroidTracker(max_disappeared, max_distance)
        self.smoothers = {}  # face_id -> EMA
        self.debouncers = {}  # face_id -> Debouncer
        self.smoothing_alpha = smoothing_alpha
        self.debounce_frames = debounce_frames
        self.face_emotions = {}  # face_id -> (top_emotion, scores)
        
    def update(self, detections: List[Dict]) -> Dict[int, Dict]:
        """
        Update tracker with new detections
        
        Args:
            detections: List of detection dicts with 'box' and 'emotions'
            
        Returns:
            Dictionary mapping face_id to detection data with smoothed emotions
        """
        # Extract boxes from detections
        face_boxes = [d['box'] for d in detections]
        
        # Update centroid tracker
        tracked_faces = self.centroid_tracker.update(face_boxes)
        
        # Create reverse mapping: box -> face_id
        box_to_id = {}
        for face_id, box in tracked_faces.items():
            box_to_id[box] = face_id
        
        result = {}
        
        # Process each detection
        for detection in detections:
            box = detection['box']
            
            # Skip if not tracked
            if box not in box_to_id:
                continue
                
            face_id = box_to_id[box]
            
            # Initialize smoother and debouncer for new faces
            if face_id not in self.smoothers:
                from utils import ExponentialMovingAverage, EmotionDebouncer
                self.smoothers[face_id] = ExponentialMovingAverage(self.smoothing_alpha)
                self.debouncers[face_id] = EmotionDebouncer(self.debounce_frames)
            
            # Get raw emotion scores
            raw_scores = detection['emotions']
            
            # Apply smoothing
            smoothed_scores = self.smoothers[face_id].update(raw_scores)
            
            # Get top emotion
            top_emotion = max(smoothed_scores, key=smoothed_scores.get)
            
            # Apply debouncing
            stable_emotion = self.debouncers[face_id].update(top_emotion)
            
            # Store result
            result[face_id] = {
                'box': box,
                'emotions': smoothed_scores,
                'top_emotion': stable_emotion,
                'confidence': smoothed_scores[stable_emotion]
            }
            
            self.face_emotions[face_id] = (stable_emotion, smoothed_scores)
        
        # Clean up smoothers for disappeared faces
        active_ids = set(tracked_faces.keys())
        for face_id in list(self.smoothers.keys()):
            if face_id not in active_ids:
                del self.smoothers[face_id]
                del self.debouncers[face_id]
                if face_id in self.face_emotions:
                    del self.face_emotions[face_id]
        
        return result
    
    def get_face_emotion(self, face_id: int) -> Tuple[str, Dict]:
        """Get current emotion for a face"""
        return self.face_emotions.get(face_id, ("neutral", {}))
    
    def get_active_faces(self) -> List[int]:
        """Get list of active face IDs"""
        return self.centroid_tracker.get_active_faces()
    
    def reset(self):
        """Reset all tracking state"""
        self.centroid_tracker.reset()
        self.smoothers = {}
        self.debouncers = {}
        self.face_emotions = {}
