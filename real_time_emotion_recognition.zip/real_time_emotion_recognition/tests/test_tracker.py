"""
Unit tests for face tracking
"""

import pytest
from tracker import CentroidTracker, FaceTracker


class TestCentroidTracker:
    """Test centroid-based tracking"""
    
    def test_initialization(self):
        """Test tracker initializes correctly"""
        tracker = CentroidTracker(max_disappeared=30, max_distance=50)
        assert tracker.next_object_id == 0
        assert len(tracker.objects) == 0
    
    def test_register_new_face(self):
        """Test registering new face"""
        tracker = CentroidTracker()
        
        face_id = tracker.register((100.0, 100.0))
        
        assert face_id == 0
        assert tracker.objects[face_id] == (100.0, 100.0)
        assert tracker.disappeared[face_id] == 0
    
    def test_update_with_single_face(self):
        """Test tracking single face"""
        tracker = CentroidTracker()
        
        # First frame
        boxes = [(50, 50, 100, 100)]
        result = tracker.update(boxes)
        
        assert len(result) == 1
        face_id = list(result.keys())[0]
        assert result[face_id] == boxes[0]
    
    def test_update_maintains_id(self):
        """Test face ID maintained across frames"""
        tracker = CentroidTracker(max_distance=50)
        
        # Frame 1
        boxes1 = [(50, 50, 100, 100)]
        result1 = tracker.update(boxes1)
        face_id = list(result1.keys())[0]
        
        # Frame 2 - slight movement
        boxes2 = [(55, 55, 100, 100)]
        result2 = tracker.update(boxes2)
        
        # Should maintain same ID
        assert face_id in result2
    
    def test_multiple_faces(self):
        """Test tracking multiple faces"""
        tracker = CentroidTracker()
        
        boxes = [
            (50, 50, 100, 100),
            (200, 50, 100, 100),
            (50, 200, 100, 100)
        ]
        
        result = tracker.update(boxes)
        
        assert len(result) == 3
    
    def test_face_disappearance(self):
        """Test face disappearing and reappearing"""
        tracker = CentroidTracker(max_disappeared=2)
        
        # Frame 1 - face present
        boxes1 = [(50, 50, 100, 100)]
        result1 = tracker.update(boxes1)
        face_id = list(result1.keys())[0]
        
        # Frame 2 - face disappears
        result2 = tracker.update([])
        assert tracker.disappeared[face_id] == 1
        
        # Frame 3 - still disappeared
        result3 = tracker.update([])
        assert tracker.disappeared[face_id] == 2
        
        # Frame 4 - should be deregistered
        result4 = tracker.update([])
        assert face_id not in tracker.objects
    
    def test_new_face_added(self):
        """Test new face added to existing tracking"""
        tracker = CentroidTracker()
        
        # Frame 1 - one face
        boxes1 = [(50, 50, 100, 100)]
        result1 = tracker.update(boxes1)
        
        # Frame 2 - two faces
        boxes2 = [(50, 50, 100, 100), (200, 50, 100, 100)]
        result2 = tracker.update(boxes2)
        
        assert len(result2) == 2
    
    def test_reset(self):
        """Test reset clears all state"""
        tracker = CentroidTracker()
        tracker.update([(50, 50, 100, 100)])
        
        tracker.reset()
        
        assert tracker.next_object_id == 0
        assert len(tracker.objects) == 0
        assert len(tracker.disappeared) == 0


class TestFaceTracker:
    """Test high-level face tracker"""
    
    def test_initialization(self):
        """Test face tracker initializes"""
        tracker = FaceTracker(
            max_disappeared=30,
            max_distance=50,
            smoothing_alpha=0.3,
            debounce_frames=5
        )
        
        assert tracker.smoothing_alpha == 0.3
        assert tracker.debounce_frames == 5
    
    def test_update_with_detections(self):
        """Test updating with emotion detections"""
        tracker = FaceTracker()
        
        detections = [{
            'box': (50, 50, 100, 100),
            'emotions': {
                'happy': 0.8,
                'sad': 0.1,
                'angry': 0.05,
                'neutral': 0.03,
                'surprise': 0.01,
                'fear': 0.005,
                'disgust': 0.005
            }
        }]
        
        result = tracker.update(detections)
        
        assert len(result) == 1
        face_id = list(result.keys())[0]
        assert 'box' in result[face_id]
        assert 'emotions' in result[face_id]
        assert 'top_emotion' in result[face_id]
        assert 'confidence' in result[face_id]
    
    def test_emotion_smoothing(self):
        """Test emotion scores are smoothed"""
        tracker = FaceTracker(smoothing_alpha=0.5, debounce_frames=1)
        
        # First detection - happy
        detections1 = [{
            'box': (50, 50, 100, 100),
            'emotions': {'happy': 1.0, 'sad': 0.0, 'angry': 0.0, 'neutral': 0.0,
                        'surprise': 0.0, 'fear': 0.0, 'disgust': 0.0}
        }]
        result1 = tracker.update(detections1)
        
        # Second detection - sad (same face, slight movement)
        detections2 = [{
            'box': (52, 52, 100, 100),
            'emotions': {'happy': 0.0, 'sad': 1.0, 'angry': 0.0, 'neutral': 0.0,
                        'surprise': 0.0, 'fear': 0.0, 'disgust': 0.0}
        }]
        result2 = tracker.update(detections2)
        
        # Should be smoothed (not 0 or 1)
        face_id = list(result2.keys())[0]
        emotions = result2[face_id]['emotions']
        
        # With alpha=0.5, should be around 0.5
        assert 0.4 < emotions['happy'] < 0.6
        assert 0.4 < emotions['sad'] < 0.6
    
    def test_get_active_faces(self):
        """Test getting active face IDs"""
        tracker = FaceTracker()
        
        detections = [
            {'box': (50, 50, 100, 100), 
             'emotions': {'happy': 0.8, 'sad': 0.1, 'angry': 0.05, 'neutral': 0.03,
                         'surprise': 0.01, 'fear': 0.005, 'disgust': 0.005}},
            {'box': (200, 50, 100, 100),
             'emotions': {'happy': 0.6, 'sad': 0.2, 'angry': 0.1, 'neutral': 0.05,
                         'surprise': 0.03, 'fear': 0.01, 'disgust': 0.01}}
        ]
        
        tracker.update(detections)
        active = tracker.get_active_faces()
        
        assert len(active) == 2
    
    def test_reset(self):
        """Test reset clears all tracking"""
        tracker = FaceTracker()
        
        detections = [{
            'box': (50, 50, 100, 100),
            'emotions': {'happy': 0.8, 'sad': 0.1, 'angry': 0.05, 'neutral': 0.03,
                        'surprise': 0.01, 'fear': 0.005, 'disgust': 0.005}
        }]
        
        tracker.update(detections)
        tracker.reset()
        
        assert len(tracker.smoothers) == 0
        assert len(tracker.debouncers) == 0
        assert len(tracker.face_emotions) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
