"""
Test suite for Real-time Emotion Recognition
"""
