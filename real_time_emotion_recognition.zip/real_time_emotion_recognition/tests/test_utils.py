"""
Unit tests for utility functions
"""

import os
import tempfile
from collections import defaultdict

import numpy as np
import pytest

from utils import (EMOTIONS, EmotionDebouncer, EmotionLogger,
                   ExponentialMovingAverage, SessionStats, blur_background,
                   calculate_fps, get_emotion_color, save_screenshot)


class TestExponentialMovingAverage:
    """Test EMA smoothing"""
    
    def test_initialization(self):
        """Test EMA initializes correctly"""
        ema = ExponentialMovingAverage(alpha=0.3)
        assert ema.alpha == 0.3
        assert ema.values == {}
    
    def test_first_update(self):
        """Test first update sets initial values"""
        ema = ExponentialMovingAverage(alpha=0.3)
        scores = {'happy': 0.8, 'sad': 0.2}
        result = ema.update(scores)
        
        assert result == scores
        assert ema.values == scores
    
    def test_smoothing(self):
        """Test EMA smoothing formula"""
        ema = ExponentialMovingAverage(alpha=0.5)
        
        # First update
        scores1 = {'happy': 1.0, 'sad': 0.0}
        result1 = ema.update(scores1)
        assert result1 == {'happy': 1.0, 'sad': 0.0}
        
        # Second update - should smooth
        scores2 = {'happy': 0.0, 'sad': 1.0}
        result2 = ema.update(scores2)
        
        # With alpha=0.5: new = 0.5 * 0.0 + 0.5 * 1.0 = 0.5
        assert result2['happy'] == 0.5
        assert result2['sad'] == 0.5
    
    def test_reset(self):
        """Test reset clears state"""
        ema = ExponentialMovingAverage(alpha=0.3)
        ema.update({'happy': 0.8})
        ema.reset()
        assert ema.values == {}


class TestEmotionDebouncer:
    """Test emotion debouncing"""
    
    def test_initialization(self):
        """Test debouncer initializes correctly"""
        debouncer = EmotionDebouncer(debounce_frames=5)
        assert debouncer.debounce_frames == 5
        assert debouncer.current_emotion == "neutral"
    
    def test_no_change_same_emotion(self):
        """Test no change when same emotion"""
        debouncer = EmotionDebouncer(debounce_frames=3)
        
        for _ in range(5):
            result = debouncer.update("neutral")
            assert result == "neutral"
    
    def test_change_after_threshold(self):
        """Test emotion changes after N frames"""
        debouncer = EmotionDebouncer(debounce_frames=3)
        
        # Start with neutral
        assert debouncer.current_emotion == "neutral"
        
        # Send happy 2 times - should not change yet
        assert debouncer.update("happy") == "neutral"
        assert debouncer.update("happy") == "neutral"
        
        # 3rd time should change
        assert debouncer.update("happy") == "happy"
    
    def test_reset_on_different_candidate(self):
        """Test candidate resets when different emotion appears"""
        debouncer = EmotionDebouncer(debounce_frames=3)
        
        debouncer.update("happy")
        debouncer.update("happy")
        # Different emotion - resets count
        debouncer.update("sad")
        
        # Happy count should have reset
        assert debouncer.candidate_emotion == "sad"
        assert debouncer.candidate_count == 1
    
    def test_reset_method(self):
        """Test reset method"""
        debouncer = EmotionDebouncer(debounce_frames=3)
        debouncer.update("happy")
        debouncer.reset()
        
        assert debouncer.current_emotion == "neutral"
        assert debouncer.candidate_count == 0


class TestEmotionLogger:
    """Test CSV logging"""
    
    def test_start_logging_creates_file(self):
        """Test logging creates CSV file"""
        with tempfile.TemporaryDirectory() as tmpdir:
            logger = EmotionLogger(log_dir=tmpdir, include_fps=True)
            log_file = logger.start_logging()
            
            assert os.path.exists(log_file)
            assert log_file.endswith('.csv')
    
    def test_log_frame_writes_data(self):
        """Test logging writes frame data"""
        with tempfile.TemporaryDirectory() as tmpdir:
            logger = EmotionLogger(log_dir=tmpdir, include_fps=True)
            logger.start_logging()
            
            scores = {emo: 0.1 for emo in EMOTIONS}
            scores['happy'] = 0.8
            
            logger.log_frame(face_id=1, top_emotion='happy', scores=scores, fps=30.0)
            logger.stop_logging()
            
            # Check file has content
            with open(logger.log_file, 'r') as f:
                content = f.read()
                assert 'happy' in content
                assert '0.8' in content


class TestSessionStats:
    """Test session statistics tracking"""
    
    def test_initialization(self):
        """Test stats initialize correctly"""
        stats = SessionStats()
        assert stats.frame_count == 0
        assert len(stats.emotion_counts) == 0
    
    def test_update_increments_counts(self):
        """Test update increments counts"""
        stats = SessionStats()
        
        stats.update(face_id=1, emotion='happy', fps=30.0)
        stats.update(face_id=1, emotion='happy', fps=30.0)
        stats.update(face_id=1, emotion='sad', fps=30.0)
        
        assert stats.frame_count == 3
        assert stats.emotion_counts['happy'] == 2
        assert stats.emotion_counts['sad'] == 1
    
    def test_streak_tracking(self):
        """Test emotion streak tracking"""
        stats = SessionStats()
        
        # Create streak of 5 happy frames
        for _ in range(5):
            stats.update(face_id=1, emotion='happy', fps=30.0)
        
        # Change to sad
        stats.update(face_id=1, emotion='sad', fps=30.0)
        
        # Max streak for happy should be 5
        assert stats.max_streaks['happy'] == 5
    
    def test_per_face_stats(self):
        """Test per-face statistics"""
        stats = SessionStats()
        
        stats.update(face_id=1, emotion='happy', fps=30.0)
        stats.update(face_id=2, emotion='sad', fps=30.0)
        stats.update(face_id=1, emotion='happy', fps=30.0)
        
        assert stats.per_face_stats[1]['frames'] == 2
        assert stats.per_face_stats[2]['frames'] == 1
    
    def test_get_summary(self):
        """Test summary generation"""
        stats = SessionStats()
        
        for _ in range(10):
            stats.update(face_id=1, emotion='happy', fps=30.0)
        
        summary = stats.get_summary()
        
        assert 'session' in summary
        assert 'emotions' in summary
        assert 'fps' in summary
        assert 'per_face' in summary
        assert summary['emotions']['most_frequent'] == 'happy'


class TestUtilityFunctions:
    """Test utility helper functions"""
    
    def test_calculate_fps(self):
        """Test FPS calculation"""
        fps, _ = calculate_fps(prev_time=0.0, current_time=0.1, smooth_fps=0.0, alpha=0.1)
        # Should be around 10 fps (1 / 0.1)
        assert 9.0 < fps < 11.0
    
    def test_get_emotion_color(self):
        """Test emotion color mapping"""
        color = get_emotion_color('happy')
        assert isinstance(color, tuple)
        assert len(color) == 3
        
        # All values should be in valid range
        assert all(0 <= c <= 255 for c in color)
    
    def test_save_screenshot(self):
        """Test screenshot saving"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create dummy frame
            frame = np.zeros((100, 100, 3), dtype=np.uint8)
            
            filename = save_screenshot(frame, directory=tmpdir, mask_faces=False)
            
            assert os.path.exists(filename)
            assert filename.endswith('.png')
    
    def test_blur_background(self):
        """Test background blurring"""
        frame = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        face_boxes = [(20, 20, 30, 30)]
        
        blurred = blur_background(frame, face_boxes)
        
        # Output should have same shape
        assert blurred.shape == frame.shape
        
        # Face region should be unchanged
        assert np.array_equal(blurred[20:50, 20:50], frame[20:50, 20:50])


def test_emotion_constants():
    """Test emotion constants are defined"""
    assert len(EMOTIONS) == 7
    assert 'happy' in EMOTIONS
    assert 'sad' in EMOTIONS
    assert 'neutral' in EMOTIONS


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
