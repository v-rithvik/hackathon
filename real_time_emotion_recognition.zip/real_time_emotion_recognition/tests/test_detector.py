"""
Unit tests for emotion detector backends
"""

import numpy as np
import pytest

from detector import DummyDetector, FERDetector, create_detector


class TestDummyDetector:
    """Test dummy detector for testing"""
    
    def test_initialization(self):
        """Test dummy detector initializes"""
        detector = DummyDetector()
        assert detector.get_backend_name() == "Dummy (Testing)"
    
    def test_detect_emotions(self):
        """Test dummy detection returns valid format"""
        detector = DummyDetector()
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        
        results = detector.detect_emotions(frame)
        
        assert len(results) == 1
        assert 'box' in results[0]
        assert 'emotions' in results[0]
        assert len(results[0]['emotions']) == 7


class TestFERDetector:
    """Test FER detector"""
    
    def test_initialization(self):
        """Test FER detector initializes"""
        try:
            detector = FERDetector(mtcnn=False)
            assert "FER" in detector.get_backend_name()
        except ImportError:
            pytest.skip("FER not installed")
    
    def test_detect_format(self):
        """Test FER returns correct format"""
        try:
            detector = FERDetector(mtcnn=False)
            # Create simple test image
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
            
            results = detector.detect_emotions(frame)
            
            # Should return list
            assert isinstance(results, list)
            
            # Each result should have box and emotions
            for result in results:
                assert 'box' in result
                assert 'emotions' in result
                assert isinstance(result['box'], tuple)
                assert isinstance(result['emotions'], dict)
        except ImportError:
            pytest.skip("FER not installed")


class TestDetectorFactory:
    """Test detector factory function"""
    
    def test_create_fer_detector(self):
        """Test creating FER detector"""
        try:
            detector = create_detector("fer", mtcnn=False)
            assert isinstance(detector, FERDetector)
        except ImportError:
            pytest.skip("FER not installed")
    
    def test_create_dummy_detector(self):
        """Test creating dummy detector"""
        detector = create_detector("dummy")
        assert isinstance(detector, DummyDetector)
    
    def test_invalid_backend_raises_error(self):
        """Test invalid backend raises error"""
        with pytest.raises(ValueError):
            create_detector("invalid_backend")


class TestDetectorInterface:
    """Test detector interface compliance"""
    
    def test_dummy_detector_interface(self):
        """Test dummy detector implements interface"""
        detector = DummyDetector()
        
        # Should have required methods
        assert hasattr(detector, 'detect_emotions')
        assert hasattr(detector, 'get_backend_name')
        
        # Methods should be callable
        assert callable(detector.detect_emotions)
        assert callable(detector.get_backend_name)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
