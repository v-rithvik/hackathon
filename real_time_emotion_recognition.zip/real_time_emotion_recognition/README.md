# 😊 Real-time Emotion Recognition System

A professional, production-ready facial emotion recognition system with real-time processing, multi-face tracking, and beautiful Streamlit UI. Perfect for hackathons, research, and production deployments.

![Python](https://img.shields.io/badge/python-3.11+-blue.svg)
![OpenCV](https://img.shields.io/badge/OpenCV-4.8+-green.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.28+-red.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

## ✨ Features

### 🎯 Core Capabilities
- **Real-time Emotion Detection** - Detect 7 emotions: happy, sad, angry, surprise, fear, disgust, neutral
- **Multi-Face Tracking** - Track multiple faces simultaneously with stable ID assignment
- **Dual Backend Support** - Switch between FER (fast) and DeepFace (accurate)
- **Temporal Smoothing** - EMA smoothing + debouncing for stable emotion readings
- **Performance Mode** - Frame skipping and optimization for low-end hardware

### 🎨 Beautiful Streamlit UI
- **Live Video Feed** - Real-time webcam display with emotion overlays
- **Interactive Controls** - Start/stop, settings sidebar, face selection
- **Emotion Visualizations** - Bar charts + 60-second rolling timeline
- **Session Statistics** - FPS, frame count, per-face analytics
- **Alert System** - Visual + audio alerts for negative emotions
- **Export Capabilities** - Screenshots, CSV logs, JSON summaries

### 🔒 Privacy Features
- **Background Blur** - Blur everything except detected faces
- **Face Masking** - Optionally blur faces in screenshots
- **No-Record Mode** - In-memory only processing (no file writes)

### 📊 Analytics & Logging
- **CSV Logging** - Timestamped emotion data per face
- **Session Summaries** - Export detailed JSON reports with statistics
- **Emotion Streaks** - Track longest consecutive emotion periods
- **FPS Tracking** - Monitor performance metrics

## 🚀 Quick Start

### Installation

```bash
# 1. Clone or download this repository
cd real_time_emotion_recognition

# 2. Create virtual environment (recommended)
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# Optional: Install pre-commit hooks
pre-commit install
```

### Run Streamlit UI (Recommended)

```bash
# Start the beautiful web interface
streamlit run app.py
```

Then open your browser to `http://localhost:8501`

### Run CLI Mode

```bash
# Basic usage
python main.py

# With options
python main.py --fps --draw-box --emoji --alerts

# Performance mode
python main.py --perf --resize 480

# Enable logging
python main.py --log --fps

# Use DeepFace backend
python main.py --backend deepface
```

**CLI Controls:**
- `q` - Quit
- `s` - Take screenshot
- `l` - Toggle logging
- `e` - Export session summary

## 📁 Project Structure

```
real_time_emotion_recognition/
├── app.py                      # Streamlit UI (main web app)
├── main.py                     # CLI runner
├── detector.py                 # Emotion detector abstraction layer
├── tracker.py                  # Multi-face tracking with centroid algorithm
├── utils.py                    # Utilities (smoothing, logging, helpers)
├── config.yaml                 # Configuration settings
├── requirements.txt            # Python dependencies
├── Makefile                    # Development commands
├── Dockerfile                  # Container definition
├── .pre-commit-config.yaml     # Code quality hooks
├── tests/                      # Unit tests
│   ├── __init__.py
│   ├── test_detector.py
│   ├── test_tracker.py
│   └── test_utils.py
├── logs/                       # Auto-generated CSV logs
├── shots/                      # Screenshots
├── exports/                    # JSON session summaries
└── README.md                   # This file
```

## 🎛️ Configuration

Edit `config.yaml` to customize:

```yaml
camera:
  index: 0                      # Webcam device (0, 1, 2...)
  resize_height: 720            # Processing resolution

detector:
  backend: "fer"                # "fer" or "deepface"
  mtcnn: false                  # Use MTCNN face detector

smoothing:
  enabled: true
  alpha: 0.3                    # Smoothing factor (0-1)
  debounce_frames: 5            # Frames before emotion change

performance:
  enabled: false
  frame_skip: 2                 # Process every Nth frame

alerts:
  enabled: true
  emotions: ["angry", "sad"]
  threshold: 0.80
  min_frames: 10
```

## 🎯 Use Cases

### Research & Development
- Emotion recognition algorithm testing
- Dataset collection and annotation
- Human-computer interaction studies

### Production Applications
- Customer sentiment analysis
- Focus group monitoring
- Mental health assessment tools
- Gaming emotion-based controls

### Education
- Psychology courses
- Computer vision tutorials
- AI/ML demonstrations

## 🧪 Testing

```bash
# Run all tests
pytest tests/ -v

# With coverage
pytest tests/ --cov=. --cov-report=html

# Run specific test file
pytest tests/test_utils.py -v
```

## 🐳 Docker Deployment

```bash
# Build image
docker build -t emotion-recognition:latest .

# Run container (Linux)
docker run -p 8501:8501 --device=/dev/video0 emotion-recognition:latest

# Windows/Mac - requires camera passthrough setup
```

## 📊 Backend Comparison

| Feature | FER | DeepFace |
|---------|-----|----------|
| Speed | ⚡ Fast (30+ FPS) | 🐢 Slower (5-15 FPS) |
| Accuracy | ✅ Good | ✅✅ Excellent |
| Setup | Easy | Moderate |
| Dependencies | Lightweight | Heavy (TensorFlow) |
| Best For | Real-time apps | High accuracy needs |

## 🔧 Troubleshooting

### Camera Not Detected

**Windows:**
```bash
# Try different camera indices
python main.py --camera 1
python main.py --camera 2

# Check Windows privacy settings
# Settings → Privacy → Camera → Allow apps to access camera
```

**Linux:**
```bash
# Check available cameras
ls /dev/video*

# Grant permissions
sudo usermod -a -G video $USER
```

**Mac:**
```bash
# Grant terminal camera access
# System Preferences → Security & Privacy → Camera
```

### OpenCV Issues

```bash
# Reinstall OpenCV
pip uninstall opencv-python opencv-python-headless
pip install opencv-python

# For headless servers
pip install opencv-python-headless
```

### DeepFace Model Downloads

First run with DeepFace will download models (~100MB). This may take time:

```python
# Pre-download models
from deepface import DeepFace
DeepFace.build_model("Emotion")
```

### Low FPS / Performance

```bash
# Enable performance mode
python main.py --perf --resize 480

# Or edit config.yaml:
performance:
  enabled: true
  frame_skip: 3

# Reduce resolution
camera:
  resize_height: 480
```

### Import Errors

```bash
# Ensure all dependencies installed
pip install -r requirements.txt --upgrade

# Check Python version (3.11+ recommended)
python --version
```

## 🎨 Streamlit UI Features

### Settings Sidebar
- **Camera Settings** - Index, resolution
- **Display Options** - FPS, boxes, emojis, blur
- **Backend Selection** - FER vs DeepFace
- **Smoothing Controls** - Alpha, debounce frames
- **Performance Mode** - Frame skip settings
- **Alert Configuration** - Thresholds, min frames

### Main Display
- **Live Video** - Real-time webcam feed with overlays
- **Current Emotion** - Large display with emoji
- **Emotion Bar Chart** - Live confidence scores
- **Timeline Graph** - 60-second rolling history
- **Face Selector** - Choose which face to track

### Actions
- **Start/Stop Webcam** - Control capture
- **Screenshot** - Save current frame
- **Export Summary** - Download session JSON
- **Start/Stop Logging** - CSV data recording

## 📈 Performance Tips

1. **Lower Resolution** - Set `resize_height: 480` for faster processing
2. **Enable Performance Mode** - Skip frames intelligently
3. **Use FER Backend** - 3-5x faster than DeepFace
4. **Disable Smoothing** - For maximum speed (less stable)
5. **Close Other Apps** - Free up CPU/GPU resources

## 🔐 Privacy Notes

This system processes video **locally on your device**. No data is sent to external servers unless you explicitly add that functionality.

**Privacy Options:**
- **Blur Background** - Hide everything except faces
- **Mask Screenshots** - Blur faces in saved images
- **No-Record Mode** - Disable all file writes
- **Local Processing** - All computation on-device

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `pytest tests/`
5. Format code: `make format`
6. Submit a pull request

## 📝 License

MIT License - feel free to use in your projects!

## 🙏 Acknowledgments

- **FER** - [justinshenk/fer](https://github.com/justinshenk/fer)
- **DeepFace** - [serengil/deepface](https://github.com/serengil/deepface)
- **OpenCV** - Computer vision foundation
- **Streamlit** - Amazing UI framework

## 📧 Support

Having issues? Check:
1. [Troubleshooting](#-troubleshooting) section above
2. GitHub Issues (if repository is hosted)
3. Verify all dependencies installed correctly

## 🚀 Advanced Usage

### Custom Emotion Models

```python
# In detector.py, add your custom detector
class CustomDetector(EmotionDetector):
    def detect_emotions(self, frame):
        # Your implementation
        pass
```

### Integration Examples

**Flask API:**
```python
from flask import Flask, jsonify
from detector import create_detector

app = Flask(__name__)
detector = create_detector("fer")

@app.route('/analyze', methods=['POST'])
def analyze():
    # Process image and return emotions
    pass
```

**Discord Bot:**
```python
import discord
from detector import create_detector

# Analyze user webcam screenshots
```

## 📊 Example Output

**Session Summary JSON:**
```json
{
  "session": {
    "start_time": "2025-01-15T10:30:00",
    "runtime_seconds": 120.5,
    "total_frames": 3615
  },
  "emotions": {
    "most_frequent": "happy",
    "counts": {"happy": 2500, "neutral": 800, "sad": 315},
    "max_streaks": {"happy": 450, "neutral": 120}
  },
  "fps": {
    "average": 30.0,
    "min": 25.5,
    "max": 35.2
  }
}
```

## 🎓 Learn More

- [OpenCV Documentation](https://docs.opencv.org/)
- [Streamlit Docs](https://docs.streamlit.io/)
- [FER GitHub](https://github.com/justinshenk/fer)
- [DeepFace GitHub](https://github.com/serengil/deepface)

---

**Built with ❤️ for the Computer Vision community**

⭐ If you find this useful, please star the repository!
