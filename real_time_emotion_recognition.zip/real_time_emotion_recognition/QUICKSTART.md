# 🚀 Quick Start Guide

Get up and running in 5 minutes!

## Step 1: Install Dependencies

### Windows
```powershell
# Option A: Use setup script (recommended)
.\setup.ps1

# Option B: Manual setup
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### macOS/Linux
```bash
# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## Step 2: Verify Installation

```bash
python test_setup.py
```

This will check:
- ✅ All packages installed
- ✅ Project modules working
- ✅ Camera accessible
- ✅ Configuration present

## Step 3: Run the Application

### Option A: Streamlit UI (Recommended)

```bash
streamlit run app.py
```

Then open: http://localhost:8501

**Features:**
- 📹 Live video feed
- 📊 Real-time emotion charts
- ⚙️ Interactive settings
- 📸 Screenshot button
- 📝 CSV logging
- 📈 Export summaries

### Option B: CLI Mode

```bash
# Basic
python main.py

# With all features
python main.py --fps --draw-box --emoji --alerts

# Performance mode (faster)
python main.py --perf --resize 480

# Enable logging
python main.py --log --fps
```

**Keyboard Controls:**
- `q` - Quit
- `s` - Screenshot
- `l` - Toggle logging
- `e` - Export summary

## Step 4: Customize Settings

Edit `config.yaml`:

```yaml
camera:
  index: 0              # Change if using external webcam
  resize_height: 720    # Lower for better FPS

detector:
  backend: "fer"        # or "deepface" for accuracy

performance:
  enabled: true         # Enable for low-end hardware
  frame_skip: 2         # Process every 2nd frame
```

## Common Issues

### Camera Not Working?

**Windows:**
- Check Privacy Settings → Camera → Allow apps
- Try `--camera 1` or `--camera 2`

**Linux:**
```bash
sudo usermod -a -G video $USER
# Then logout and login
```

**Mac:**
- System Preferences → Security & Privacy → Camera
- Grant Terminal camera access

### Low FPS?

```bash
# Enable performance mode
python main.py --perf --resize 480
```

Or in `config.yaml`:
```yaml
camera:
  resize_height: 480    # Lower resolution

performance:
  enabled: true
  frame_skip: 3         # Skip more frames
```

### Import Errors?

```bash
# Reinstall dependencies
pip install -r requirements.txt --upgrade

# Check Python version (need 3.11+)
python --version
```

## Next Steps

1. **Explore Streamlit UI** - Try all the buttons and settings
2. **Test Different Backends** - Compare FER vs DeepFace
3. **Adjust Smoothing** - Find your preferred responsiveness
4. **Enable Logging** - Collect emotion data
5. **Export Sessions** - Analyze your data

## Advanced Features

### Multi-Face Tracking
The system automatically tracks multiple faces with stable IDs. In the Streamlit UI, use the face selector dropdown to focus on specific people.

### Temporal Smoothing
Adjust smoothing in config.yaml:
```yaml
smoothing:
  alpha: 0.3            # Lower = smoother (0.1-0.5)
  debounce_frames: 5    # Frames before emotion change
```

### Privacy Mode
```yaml
display:
  blur_background: true    # Blur everything except faces

screenshots:
  mask_faces: true         # Blur faces in screenshots
```

### Alerts
Get notified when negative emotions detected:
```yaml
alerts:
  enabled: true
  emotions: ["angry", "sad"]
  threshold: 0.80
  min_frames: 10
  audio_enabled: true
```

## Tips for Best Results

1. **Good Lighting** - Face the light source
2. **Face Camera Directly** - Avoid extreme angles
3. **Stable Position** - Minimize head movement
4. **Close Distance** - 2-3 feet from camera
5. **Neutral Background** - Avoid clutter behind you

## Getting Help

1. Check `README.md` for full documentation
2. Run `python test_setup.py` to diagnose issues
3. Review error messages carefully
4. Try with `--resize 480` for performance

## What to Try

### Streamlit UI
1. Start webcam
2. Adjust settings in sidebar
3. Watch emotion timeline
4. Try face selector with multiple people
5. Take screenshots
6. Export session summary

### CLI Mode
1. Run with `--fps --draw-box --emoji`
2. Press `s` for screenshots
3. Press `l` to start logging
4. Make different expressions
5. Press `e` to export data
6. Analyze CSV logs

Enjoy exploring emotions! 😊
