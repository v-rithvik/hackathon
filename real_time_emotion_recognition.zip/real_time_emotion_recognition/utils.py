"""
Utility functions for emotion recognition system
- Smoothing (EMA)
- Debounce
- CSV logging
- Timestamps
- Emoji mappings
- Helper functions
"""

import csv
import json
import os
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# Emotion to emoji mapping
EMOTION_EMOJIS = {
    "angry": "😠",
    "disgust": "🤢",
    "fear": "😨",
    "happy": "😊",
    "sad": "😢",
    "surprise": "😲",
    "neutral": "😐"
}

EMOTIONS = ["angry", "disgust", "fear", "happy", "sad", "surprise", "neutral"]


class ExponentialMovingAverage:
    """Exponential Moving Average for smoothing emotion scores"""
    
    def __init__(self, alpha: float = 0.3):
        """
        Args:
            alpha: Smoothing factor (0-1). Lower = smoother but slower response
        """
        self.alpha = alpha
        self.values: Dict[str, float] = {}
        
    def update(self, scores: Dict[str, float]) -> Dict[str, float]:
        """Update EMA with new scores"""
        if not self.values:
            # Initialize with first values
            self.values = scores.copy()
            return self.values
            
        # Apply EMA formula: EMA_new = alpha * value + (1-alpha) * EMA_old
        for emotion, score in scores.items():
            if emotion in self.values:
                self.values[emotion] = self.alpha * score + (1 - self.alpha) * self.values[emotion]
            else:
                self.values[emotion] = score
                
        return self.values.copy()
    
    def reset(self):
        """Reset the EMA state"""
        self.values = {}


class EmotionDebouncer:
    """Debounce emotion changes - only change after N stable frames"""
    
    def __init__(self, debounce_frames: int = 5):
        """
        Args:
            debounce_frames: Number of consecutive frames needed to change emotion
        """
        self.debounce_frames = debounce_frames
        self.current_emotion = "neutral"
        self.candidate_emotion = "neutral"
        self.candidate_count = 0
        
    def update(self, top_emotion: str) -> str:
        """
        Update debouncer with new top emotion
        
        Returns:
            Stable emotion after debouncing
        """
        if top_emotion == self.current_emotion:
            # Reset candidate if same as current
            self.candidate_emotion = top_emotion
            self.candidate_count = 0
            return self.current_emotion
            
        if top_emotion == self.candidate_emotion:
            # Same candidate, increment count
            self.candidate_count += 1
            if self.candidate_count >= self.debounce_frames:
                # Switch to new emotion
                self.current_emotion = top_emotion
                self.candidate_count = 0
        else:
            # New candidate
            self.candidate_emotion = top_emotion
            self.candidate_count = 1
            
        return self.current_emotion
    
    def reset(self):
        """Reset debouncer state"""
        self.current_emotion = "neutral"
        self.candidate_emotion = "neutral"
        self.candidate_count = 0


class EmotionLogger:
    """CSV logger for emotion data"""
    
    def __init__(self, log_dir: str = "logs", include_fps: bool = True):
        """
        Args:
            log_dir: Directory to save log files
            include_fps: Include FPS in logs
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.include_fps = include_fps
        self.log_file: Optional[Path] = None
        self.csv_writer = None
        self.file_handle = None
        
    def start_logging(self) -> str:
        """Start a new log session"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / f"emotion_log_{timestamp}.csv"
        
        self.file_handle = open(self.log_file, 'w', newline='')
        fieldnames = ['timestamp', 'face_id', 'top_emotion', 'confidence']
        
        # Add all emotion scores
        fieldnames.extend(EMOTIONS)
        
        if self.include_fps:
            fieldnames.append('fps')
            
        self.csv_writer = csv.DictWriter(self.file_handle, fieldnames=fieldnames)
        self.csv_writer.writeheader()
        
        return str(self.log_file)
    
    def log_frame(self, face_id: int, top_emotion: str, scores: Dict[str, float], 
                  fps: Optional[float] = None):
        """Log a single frame's data"""
        if not self.csv_writer:
            return
            
        row = {
            'timestamp': datetime.now().isoformat(),
            'face_id': face_id,
            'top_emotion': top_emotion,
            'confidence': scores.get(top_emotion, 0.0)
        }
        
        # Add emotion scores
        for emotion in EMOTIONS:
            row[emotion] = scores.get(emotion, 0.0)
            
        if self.include_fps and fps is not None:
            row['fps'] = round(fps, 2)
            
        self.csv_writer.writerow(row)
        
    def stop_logging(self):
        """Stop logging and close file"""
        if self.file_handle:
            self.file_handle.close()
            self.file_handle = None
            self.csv_writer = None


class SessionStats:
    """Track session statistics"""
    
    def __init__(self):
        self.start_time = datetime.now()
        self.emotion_counts = defaultdict(int)
        self.emotion_durations = defaultdict(float)
        self.emotion_streaks = defaultdict(int)
        self.current_streak_emotion = "neutral"
        self.current_streak_count = 0
        self.max_streaks = defaultdict(int)
        self.fps_values = deque(maxlen=100)
        self.frame_count = 0
        self.per_face_stats = defaultdict(lambda: {
            'emotions': defaultdict(int),
            'frames': 0
        })
        
    def update(self, face_id: int, emotion: str, fps: Optional[float] = None):
        """Update statistics with new frame data"""
        self.frame_count += 1
        self.emotion_counts[emotion] += 1
        
        # Update per-face stats
        self.per_face_stats[face_id]['emotions'][emotion] += 1
        self.per_face_stats[face_id]['frames'] += 1
        
        # Track streaks
        if emotion == self.current_streak_emotion:
            self.current_streak_count += 1
        else:
            if self.current_streak_count > self.max_streaks[self.current_streak_emotion]:
                self.max_streaks[self.current_streak_emotion] = self.current_streak_count
            self.current_streak_emotion = emotion
            self.current_streak_count = 1
            
        if fps is not None:
            self.fps_values.append(fps)
            
    def get_summary(self) -> Dict:
        """Get session summary as dictionary"""
        runtime = (datetime.now() - self.start_time).total_seconds()
        
        # Calculate durations (approximate from frame counts assuming ~30 fps)
        fps_avg = sum(self.fps_values) / len(self.fps_values) if self.fps_values else 30.0
        for emotion, count in self.emotion_counts.items():
            self.emotion_durations[emotion] = count / fps_avg
            
        most_frequent = max(self.emotion_counts.items(), key=lambda x: x[1])[0] if self.emotion_counts else "neutral"
        
        summary = {
            'session': {
                'start_time': self.start_time.isoformat(),
                'end_time': datetime.now().isoformat(),
                'runtime_seconds': round(runtime, 2),
                'total_frames': self.frame_count
            },
            'emotions': {
                'most_frequent': most_frequent,
                'counts': dict(self.emotion_counts),
                'durations_seconds': {k: round(v, 2) for k, v in self.emotion_durations.items()},
                'max_streaks': dict(self.max_streaks)
            },
            'fps': {
                'average': round(sum(self.fps_values) / len(self.fps_values), 2) if self.fps_values else 0,
                'min': round(min(self.fps_values), 2) if self.fps_values else 0,
                'max': round(max(self.fps_values), 2) if self.fps_values else 0
            },
            'per_face': {
                str(face_id): {
                    'total_frames': stats['frames'],
                    'emotion_counts': dict(stats['emotions']),
                    'dominant_emotion': max(stats['emotions'].items(), key=lambda x: x[1])[0] if stats['emotions'] else 'neutral'
                }
                for face_id, stats in self.per_face_stats.items()
            }
        }
        
        return summary
    
    def export_json(self, export_dir: str = "exports") -> str:
        """Export summary as JSON file"""
        export_path = Path(export_dir)
        export_path.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = export_path / f"session_summary_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.get_summary(), f, indent=2)
            
        return str(filename)


def create_directories(config: Dict):
    """Create necessary directories"""
    dirs = [
        config.get('logging', {}).get('directory', 'logs'),
        config.get('screenshots', {}).get('directory', 'shots'),
        config.get('export', {}).get('directory', 'exports')
    ]
    
    for dir_path in dirs:
        Path(dir_path).mkdir(exist_ok=True)


def save_screenshot(frame: np.ndarray, directory: str = "shots", 
                   mask_faces: bool = False, face_boxes: List[Tuple] = None) -> str:
    """
    Save screenshot with optional face masking
    
    Args:
        frame: Image frame
        directory: Directory to save screenshot
        mask_faces: Whether to blur faces
        face_boxes: List of (x, y, w, h) face boxes for masking
        
    Returns:
        Path to saved screenshot
    """
    screenshot_dir = Path(directory)
    screenshot_dir.mkdir(exist_ok=True)
    
    # Apply face masking if requested
    if mask_faces and face_boxes:
        frame = frame.copy()
        for (x, y, w, h) in face_boxes:
            # Blur the face region
            face_region = frame[y:y+h, x:x+w]
            face_region = cv2.GaussianBlur(face_region, (99, 99), 30)
            frame[y:y+h, x:x+w] = face_region
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = screenshot_dir / f"screenshot_{timestamp}.png"
    
    cv2.imwrite(str(filename), frame)
    return str(filename)


def blur_background(frame: np.ndarray, face_boxes: List[Tuple]) -> np.ndarray:
    """
    Blur entire frame except face regions
    
    Args:
        frame: Image frame
        face_boxes: List of (x, y, w, h) face boxes to keep unblurred
        
    Returns:
        Frame with blurred background
    """
    if not face_boxes:
        return cv2.GaussianBlur(frame, (99, 99), 30)
    
    # Create mask for faces
    mask = np.zeros(frame.shape[:2], dtype=np.uint8)
    for (x, y, w, h) in face_boxes:
        cv2.rectangle(mask, (x, y), (x+w, y+h), 255, -1)
    
    # Blur entire frame
    blurred = cv2.GaussianBlur(frame, (99, 99), 30)
    
    # Combine: use original for faces, blurred for background
    mask_3channel = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    result = np.where(mask_3channel == 255, frame, blurred)
    
    return result


def draw_emotion_text(frame: np.ndarray, text: str, position: Tuple[int, int],
                     font_scale: float = 0.9, thickness: int = 2,
                     bg_color: Tuple = (20, 20, 20), 
                     text_color: Tuple = (240, 240, 240)) -> np.ndarray:
    """Draw text with background"""
    x, y = position
    
    # Get text size
    (text_width, text_height), baseline = cv2.getTextSize(
        text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness
    )
    
    # Draw background rectangle
    cv2.rectangle(frame, (x-5, y-text_height-10), 
                 (x+text_width+5, y+5), bg_color, -1)
    
    # Draw text
    cv2.putText(frame, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
               font_scale, text_color, thickness, cv2.LINE_AA)
    
    return frame


def play_alert_sound():
    """Play cross-platform alert beep"""
    try:
        # Try different methods for cross-platform compatibility
        import sys
        if sys.platform == 'win32':
            import winsound
            winsound.Beep(1000, 200)  # Frequency, duration
        else:
            # Unix-like systems
            print('\a', end='', flush=True)
    except Exception:
        # Fallback: just print
        print('\a', end='', flush=True)


def calculate_fps(prev_time: float, current_time: float, 
                 smooth_fps: float = 0.0, alpha: float = 0.1) -> Tuple[float, float]:
    """
    Calculate smoothed FPS
    
    Args:
        prev_time: Previous frame time
        current_time: Current frame time
        smooth_fps: Previous smoothed FPS
        alpha: Smoothing factor
        
    Returns:
        (smoothed_fps, current_time)
    """
    fps = 1.0 / (current_time - prev_time) if (current_time - prev_time) > 0 else 0
    smooth_fps = alpha * fps + (1 - alpha) * smooth_fps if smooth_fps > 0 else fps
    return smooth_fps, current_time


def get_emotion_color(emotion: str) -> Tuple[int, int, int]:
    """Get color for emotion (BGR format)"""
    colors = {
        "angry": (0, 0, 255),      # Red
        "disgust": (0, 128, 128),  # Teal
        "fear": (128, 0, 128),     # Purple
        "happy": (0, 255, 255),    # Yellow
        "sad": (255, 0, 0),        # Blue
        "surprise": (0, 165, 255), # Orange
        "neutral": (200, 200, 200) # Gray
    }
    return colors.get(emotion, (255, 255, 255))
