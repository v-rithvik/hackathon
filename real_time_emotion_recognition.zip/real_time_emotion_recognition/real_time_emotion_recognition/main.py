#!/usr/bin/env python3
"""
CLI Runner for Real-time Emotion Recognition
Command-line interface with all features
"""

import argparse
import time
from pathlib import Path

import cv2
import yaml

from detector import create_detector
from tracker import FaceTracker
from utils import (EMOTION_EMOJIS, EMOTIONS, EmotionLogger, SessionStats,
                   blur_background, create_directories, draw_emotion_text,
                   get_emotion_color, play_alert_sound, save_screenshot)


def draw_bars(frame, scores, origin=(10, 60), width=200, bar_height=18, gap=6):
    """Draw horizontal bar chart of emotion scores"""
    x0, y0 = origin
    max_score = max(scores.values()) if scores else 1e-9
    
    for i, emo in enumerate(EMOTIONS):
        y = y0 + i * (bar_height + gap)
        val = float(scores.get(emo, 0.0))
        w = int((val / max_score) * width) if max_score > 0 else 0
        
        # Background bar
        cv2.rectangle(frame, (x0, y), (x0 + width, y + bar_height), (40, 40, 40), -1)
        
        # Value bar with color
        color = get_emotion_color(emo)
        cv2.rectangle(frame, (x0, y), (x0 + w, y + bar_height), color, -1)
        
        # Label
        label = f"{emo}: {val:.2f}"
        cv2.putText(frame, label, (x0 + 5, y + bar_height - 4),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)


def main():
    """Main CLI function"""
    ap = argparse.ArgumentParser(description="Real-time Emotion Recognition CLI")
    ap.add_argument("--camera", type=int, default=0, help="Webcam index (default 0)")
    ap.add_argument("--resize", type=int, default=720, help="Resize height (default 720)")
    ap.add_argument("--draw-box", action="store_true", help="Draw face boxes")
    ap.add_argument("--fps", action="store_true", help="Show FPS")
    ap.add_argument("--backend", type=str, default="fer", choices=["fer", "deepface"],
                   help="Detection backend (default: fer)")
    ap.add_argument("--mtcnn", action="store_true", help="Use MTCNN (FER only)")
    ap.add_argument("--perf", action="store_true", help="Enable performance mode")
    ap.add_argument("--log", action="store_true", help="Enable logging")
    ap.add_argument("--config", type=str, default="config.yaml", help="Config file path")
    ap.add_argument("--emoji", action="store_true", help="Show emoji overlay")
    ap.add_argument("--blur-bg", action="store_true", help="Blur background (privacy)")
    ap.add_argument("--alerts", action="store_true", help="Enable audio alerts")
    args = ap.parse_args()
    
    # Load config
    config = {}
    if Path(args.config).exists():
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
    
    # Create directories
    create_directories(config)
    
    # Open webcam
    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open webcam {args.camera}. Check permissions.")
    
    print(f"📹 Opened webcam: {args.camera}")
    
    # Initialize detector
    try:
        if args.backend == "fer":
            detector = create_detector("fer", mtcnn=args.mtcnn)
        else:
            detector = create_detector("deepface")
        print(f"🧠 Detector: {detector.get_backend_name()}")
    except Exception as e:
        print(f"❌ Error initializing detector: {e}")
        return
    
    # Initialize tracker
    tracker = FaceTracker(
        max_disappeared=config.get('tracking', {}).get('max_disappeared', 30),
        max_distance=config.get('tracking', {}).get('centroid_distance_thresh', 50),
        smoothing_alpha=config.get('smoothing', {}).get('alpha', 0.3),
        debounce_frames=config.get('smoothing', {}).get('debounce_frames', 5)
    )
    
    # Initialize logger
    logger = None
    if args.log:
        logger = EmotionLogger(
            log_dir=config.get('logging', {}).get('directory', 'logs'),
            include_fps=True
        )
        log_file = logger.start_logging()
        print(f"📝 Logging to: {log_file}")
    
    # Initialize stats
    stats = SessionStats()
    
    # Performance mode settings
    frame_skip = config.get('performance', {}).get('frame_skip', 2) if args.perf else 1
    frame_counter = 0
    last_detections = {}
    
    # Alert settings
    alert_counts = {}
    alert_threshold = config.get('alerts', {}).get('threshold', 0.8)
    alert_min_frames = config.get('alerts', {}).get('min_frames', 10)
    
    # FPS tracking
    prev_time = time.time()
    smooth_fps = 0.0
    
    print("\n🚀 Starting emotion recognition...")
    print("📋 Controls:")
    print("  - 'q': Quit")
    print("  - 's': Screenshot")
    print("  - 'l': Toggle logging")
    print("  - 'e': Export summary\n")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("❌ Failed to read frame")
                break
            
            # Resize
            if args.resize and frame.shape[0] > 0:
                h = args.resize
                scale = h / frame.shape[0]
                frame = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            
            # Frame skipping for performance
            frame_counter += 1
            should_process = frame_counter >= frame_skip
            
            if should_process:
                frame_counter = 0
                
                # Convert to RGB
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # Detect emotions
                detections = detector.detect_emotions(rgb)
                
                # Track faces
                tracked_faces = tracker.update(detections)
                last_detections = tracked_faces
            else:
                # Reuse last detections
                tracked_faces = last_detections
            
            # Calculate FPS
            current_time = time.time()
            fps = 1.0 / (current_time - prev_time) if (current_time - prev_time) > 0 else 0
            smooth_fps = 0.1 * fps + 0.9 * smooth_fps if smooth_fps > 0 else fps
            prev_time = current_time
            
            # Process tracked faces
            display_frame = frame.copy()
            face_boxes = []
            
            for face_id, data in tracked_faces.items():
                box = data['box']
                emotions = data['emotions']
                top_emotion = data['top_emotion']
                confidence = data['confidence']
                
                x, y, w, h = box
                face_boxes.append(box)
                
                # Draw bounding box
                if args.draw_box:
                    color = get_emotion_color(top_emotion)
                    cv2.rectangle(display_frame, (x, y), (x+w, y+h), color, 2)
                    
                    # Draw label
                    label = f"#{face_id}: {top_emotion} ({confidence:.2f})"
                    cv2.putText(display_frame, label, (x, y-10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv2.LINE_AA)
                
                # Draw emoji
                if args.emoji and top_emotion in EMOTION_EMOJIS:
                    emoji = EMOTION_EMOJIS[top_emotion]
                    cv2.putText(display_frame, emoji, (x+w+5, y+30),
                               cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2)
                
                # Check alerts
                if args.alerts and top_emotion in ['angry', 'sad']:
                    if confidence >= alert_threshold:
                        alert_counts[face_id] = alert_counts.get(face_id, 0) + 1
                        if alert_counts[face_id] >= alert_min_frames:
                            print(f"🚨 ALERT: Face #{face_id} - {top_emotion.upper()} ({confidence:.2%})")
                            try:
                                play_alert_sound()
                            except:
                                pass
                            alert_counts[face_id] = 0  # Reset after alert
                    else:
                        alert_counts[face_id] = 0
                
                # Update stats
                stats.update(face_id, top_emotion, smooth_fps)
                
                # Log
                if logger:
                    logger.log_frame(face_id, top_emotion, emotions, smooth_fps)
            
            # Apply background blur if enabled
            if args.blur_bg and face_boxes:
                display_frame = blur_background(display_frame, face_boxes)
            
            # Draw emotion bars for first face
            if tracked_faces:
                first_face = list(tracked_faces.values())[0]
                emotions = first_face['emotions']
                top_emotion = first_face['top_emotion']
                confidence = first_face['confidence']
                
                # Header text
                header = f"{top_emotion.upper()} ({confidence:.2f})"
                display_frame = draw_emotion_text(display_frame, header, (12, 32))
                
                # Draw bars
                draw_bars(display_frame, emotions, origin=(10, 60))
            
            # Draw FPS
            if args.fps:
                cv2.putText(display_frame, f"FPS: {smooth_fps:.1f}",
                           (10, display_frame.shape[0]-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)
            
            # Display
            cv2.imshow("Real-time Emotion Recognition", display_frame)
            
            # Handle keyboard
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('q'):
                print("\n👋 Quitting...")
                break
            elif key == ord('s'):
                filename = save_screenshot(
                    display_frame,
                    directory=config.get('screenshots', {}).get('directory', 'shots')
                )
                print(f"📸 Screenshot saved: {filename}")
            elif key == ord('l'):
                if logger:
                    logger.stop_logging()
                    logger = None
                    print("⏹️ Logging stopped")
                else:
                    logger = EmotionLogger(
                        log_dir=config.get('logging', {}).get('directory', 'logs'),
                        include_fps=True
                    )
                    log_file = logger.start_logging()
                    print(f"📝 Logging started: {log_file}")
            elif key == ord('e'):
                filename = stats.export_json(
                    export_dir=config.get('export', {}).get('directory', 'exports')
                )
                print(f"📊 Summary exported: {filename}")
    
    except KeyboardInterrupt:
        print("\n⚠️ Interrupted by user")
    
    finally:
        # Cleanup
        if logger:
            logger.stop_logging()
        cap.release()
        cv2.destroyAllWindows()
        
        # Final summary
        print("\n📊 Session Summary:")
        summary = stats.get_summary()
        print(f"  Runtime: {summary['session']['runtime_seconds']:.1f}s")
        print(f"  Total Frames: {summary['session']['total_frames']}")
        print(f"  Most Frequent: {summary['emotions']['most_frequent']}")
        print(f"  Average FPS: {summary['fps']['average']:.1f}")
        print("\n✅ Done!\n")


if __name__ == "__main__":
    main()
