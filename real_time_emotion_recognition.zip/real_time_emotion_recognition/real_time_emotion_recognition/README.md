# Real-time Facial Expression Recognition (Python)

This is a vibe-checker for your webcam. It reads your face in real time and labels the dominant emotion
using [FER](https://github.com/justinshenk/fer) (a lightweight CNN on top of OpenCV).

## Quickstart

```bash
# 1) Create a virtual env (recommended)
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

# 2) Install deps
pip install -r requirements.txt

# 3) Run it
python main.py
# If you have multiple webcams:
python main.py --camera 1
# Draw face boxes + FPS:
python main.py --draw-box --fps
```

Press `q` to quit.

## Requirements
- Python 3.9+
- A webcam
- Packages:
  - `opencv-python`
  - `fer`

If detection is jittery, reduce the input size:
```
python main.py --resize 480
```

If you install `mtcnn` (`pip install mtcnn`), you can switch the detector to MTCNN by changing:
```python
detector = FER(mtcnn=True)
```

## Notes
- FER models aren’t perfect (lighting and camera angle matter). For better accuracy try a stronger model like `deepface` or a custom fine-tuned CNN.
- Run with good lighting and keep your face within the frame.
