# 🏗️ System Architecture

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     USER INTERFACES                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────┐      ┌─────────────────────┐      │
│  │   Streamlit UI      │      │    CLI Mode         │      │
│  │   (app.py)          │      │    (main.py)        │      │
│  │  - Live video       │      │  - Terminal display │      │
│  │  - Charts           │      │  - Keyboard control │      │
│  │  - Settings         │      │  - Command flags    │      │
│  └──────────┬──────────┘      └──────────┬──────────┘      │
│             │                            │                  │
└─────────────┼────────────────────────────┼──────────────────┘
              │                            │
              └────────────┬───────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   CORE PROCESSING LAYER                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │            Face Tracker (tracker.py)                  │  │
│  │  ┌──────────────────┐    ┌──────────────────┐        │  │
│  │  │ CentroidTracker  │    │  FaceTracker     │        │  │
│  │  │ - ID assignment  │────│  - EMA smoothing │        │  │
│  │  │ - Centroid match │    │  - Debouncing    │        │  │
│  │  └──────────────────┘    └──────────────────┘        │  │
│  └────────────────────┬─────────────────────────────────┘  │
│                       │                                     │
│                       ↓                                     │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Emotion Detector (detector.py)                │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │  │
│  │  │ FERDetector  │  │DeepFaceDetect│  │DummyDetect │  │  │
│  │  │   (Fast)     │  │   (Accurate) │  │  (Test)    │  │  │
│  │  └──────────────┘  └──────────────┘  └────────────┘  │  │
│  └────────────────────┬─────────────────────────────────┘  │
│                       │                                     │
└───────────────────────┼─────────────────────────────────────┘
                        │
                        ↓
┌─────────────────────────────────────────────────────────────┐
│                   UTILITY LAYER (utils.py)                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────┐  ┌────────────────┐  ┌──────────────┐  │
│  │      EMA       │  │   Debouncer    │  │   Logger     │  │
│  │  Smoothing     │  │   N-frame      │  │  CSV files   │  │
│  └────────────────┘  └────────────────┘  └──────────────┘  │
│                                                              │
│  ┌────────────────┐  ┌────────────────┐  ┌──────────────┐  │
│  │ SessionStats   │  │  Screenshot    │  │    Alerts    │  │
│  │  Analytics     │  │    Saver       │  │  Audio/UI    │  │
│  └────────────────┘  └────────────────┘  └──────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                        │
                        ↓
┌─────────────────────────────────────────────────────────────┐
│                     DATA LAYER                               │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐   ┌──────────┐   ┌──────────┐               │
│  │  logs/   │   │  shots/  │   │ exports/ │               │
│  │  *.csv   │   │  *.png   │   │  *.json  │               │
│  └──────────┘   └──────────┘   └──────────┘               │
└─────────────────────────────────────────────────────────────┘
```

## Component Interaction Flow

```
Frame Capture → Detection → Tracking → Smoothing → Display
                    ↓          ↓          ↓          ↓
                Backends   Face IDs    EMA/DB    UI/CLI
                    ↓          ↓          ↓          ↓
              FER/DeepFace Centroid  Debounce  Charts/Text
                                         ↓          ↓
                                     Logging   Export
```

## Data Flow Diagram

```
┌─────────┐
│ Webcam  │
└────┬────┘
     │ Raw Frame (BGR)
     ↓
┌─────────────┐
│  Resize &   │
│  RGB Convert│
└──────┬──────┘
       │ RGB Frame
       ↓
┌──────────────────┐
│ Emotion Detector │
│  (FER/DeepFace)  │
└────────┬─────────┘
         │ List[Detection]
         │ {box, emotions}
         ↓
┌──────────────────┐
│  Face Tracker    │
│  (Centroid +     │
│   EMA + Debounce)│
└────────┬─────────┘
         │ Dict[face_id -> Data]
         │ {box, emotion, confidence}
         ↓
    ┌────┴────┐
    │         │
    ↓         ↓
┌────────┐  ┌──────────┐
│Display │  │  Logging │
│ UI/CLI │  │CSV/JSON  │
└────────┘  └──────────┘
```

## Module Dependencies

```
app.py
  ├── detector.create_detector()
  ├── tracker.FaceTracker()
  ├── utils.SessionStats()
  ├── utils.EmotionLogger()
  ├── utils.save_screenshot()
  ├── utils.blur_background()
  └── utils.play_alert_sound()

main.py
  ├── detector.create_detector()
  ├── tracker.FaceTracker()
  ├── utils.EmotionLogger()
  ├── utils.SessionStats()
  └── utils.save_screenshot()

detector.py
  ├── fer.FER (external)
  ├── deepface.DeepFace (external)
  └── cv2 (external)

tracker.py
  ├── utils.ExponentialMovingAverage
  ├── utils.EmotionDebouncer
  └── scipy.spatial.distance

utils.py
  ├── cv2
  ├── numpy
  ├── csv
  └── json
```

## Class Hierarchy

```
EmotionDetector (ABC)
  ├── FERDetector
  ├── DeepFaceDetector
  └── DummyDetector

CentroidTracker
  └── (used by FaceTracker)

FaceTracker
  ├── CentroidTracker
  ├── ExponentialMovingAverage (per face)
  └── EmotionDebouncer (per face)

ExponentialMovingAverage
  └── (stateful smoothing)

EmotionDebouncer
  └── (stateful debouncing)

EmotionLogger
  └── (CSV writer)

SessionStats
  └── (analytics collector)
```

## Configuration Flow

```
config.yaml
    │
    ├─→ Camera Settings
    │     ├─ index
    │     └─ resize_height
    │
    ├─→ Detector Settings
    │     ├─ backend (fer/deepface)
    │     └─ mtcnn (bool)
    │
    ├─→ Tracking Settings
    │     ├─ max_disappeared
    │     └─ centroid_distance_thresh
    │
    ├─→ Smoothing Settings
    │     ├─ alpha
    │     └─ debounce_frames
    │
    ├─→ Performance Settings
    │     ├─ enabled
    │     └─ frame_skip
    │
    └─→ Alert Settings
          ├─ threshold
          └─ min_frames
```

## Processing Pipeline

### Streamlit UI Pipeline

```
1. User clicks "Start Webcam"
   ↓
2. Initialize detector (FER/DeepFace)
   ↓
3. Initialize tracker with smoothing
   ↓
4. Start video capture loop
   ↓
5. For each frame:
   ├─ Read frame from webcam
   ├─ Resize if needed
   ├─ Convert BGR → RGB
   ├─ Detect emotions
   ├─ Update tracker
   ├─ Apply smoothing & debouncing
   ├─ Draw visualizations
   ├─ Update UI components
   ├─ Check alerts
   ├─ Log data (if enabled)
   └─ Display frame
   ↓
6. User actions:
   ├─ Screenshot → save_screenshot()
   ├─ Export → stats.export_json()
   └─ Stop → cleanup
```

### CLI Pipeline

```
1. Parse command-line arguments
   ↓
2. Load config.yaml
   ↓
3. Initialize detector
   ↓
4. Initialize tracker
   ↓
5. Open webcam
   ↓
6. Main loop:
   ├─ Capture frame
   ├─ Detect emotions
   ├─ Track faces
   ├─ Draw overlays
   ├─ Display with OpenCV
   └─ Handle keyboard input
   ↓
7. Cleanup & summary
```

## State Management

### Streamlit Session State

```python
st.session_state = {
    'running': bool,
    'detector': EmotionDetector,
    'tracker': FaceTracker,
    'cap': cv2.VideoCapture,
    'stats': SessionStats,
    'logging_enabled': bool,
    'logger': EmotionLogger,
    'emotion_timeline': dict,
    'selected_face_id': int,
    'alert_counts': dict,
    'fps': float,
    'tracked_faces': dict
}
```

### Tracker State

```python
FaceTracker = {
    'centroid_tracker': CentroidTracker,
    'smoothers': {face_id: EMA},
    'debouncers': {face_id: Debouncer},
    'face_emotions': {face_id: (emotion, scores)}
}
```

## Performance Optimization Flow

```
Performance Mode Enabled?
    │
    ├─ Yes
    │   ├─ Lower resolution
    │   ├─ Skip frames
    │   └─ Reuse detections
    │
    └─ No
        └─ Process every frame at full resolution

Frame Skip Logic:
    frame_counter++
    if frame_counter >= skip_threshold:
        ► Detect emotions
        ► Reset counter
    else:
        ► Reuse last detections
```

## Testing Architecture

```
tests/
  ├── test_detector.py
  │     ├─ Test detector interface
  │     ├─ Test FER backend
  │     └─ Test factory function
  │
  ├── test_tracker.py
  │     ├─ Test centroid tracking
  │     ├─ Test face tracking
  │     └─ Test smoothing integration
  │
  └── test_utils.py
        ├─ Test EMA
        ├─ Test debouncer
        ├─ Test logger
        ├─ Test session stats
        └─ Test helper functions
```

## Deployment Architecture

### Local Development
```
Developer Machine
  ├─ Python virtual environment
  ├─ Direct webcam access
  └─ Streamlit dev server
```

### Docker Deployment
```
Docker Container
  ├─ Python 3.11 slim
  ├─ System dependencies
  ├─ Application code
  ├─ Streamlit production server
  └─ Camera device passthrough
```

### Cloud Deployment
```
Cloud Instance (e.g., AWS EC2)
  ├─ Docker container
  ├─ Reverse proxy (nginx)
  ├─ SSL certificate
  └─ Domain name
```

## Security & Privacy Flow

```
Privacy Mode Enabled?
    │
    ├─ Blur Background
    │   ├─ Detect faces
    │   ├─ Create face mask
    │   └─ Blur non-face regions
    │
    ├─ Mask Screenshots
    │   └─ Blur faces in saved images
    │
    └─ No-Record Mode
        └─ Disable all file writes
```

## Error Handling Strategy

```
Try-Catch Blocks:
  ├─ Camera initialization
  │   └─ Fallback: Show error message
  │
  ├─ Detector initialization
  │   └─ Fallback: Use dummy detector
  │
  ├─ Frame processing
  │   └─ Fallback: Skip frame, continue
  │
  └─ File operations
      └─ Fallback: Log error, continue
```

## Scalability Considerations

### Horizontal Scaling
- Multiple instances for different cameras
- Load balancing for batch processing
- Distributed tracking across nodes

### Vertical Scaling
- GPU acceleration (DeepFace)
- Parallel face processing
- Optimized inference

### Data Scaling
- Log rotation
- Compressed exports
- Database integration (future)

---

This architecture supports:
- ✅ Real-time processing
- ✅ Multi-face tracking
- ✅ Flexible backends
- ✅ Privacy protection
- ✅ Performance optimization
- ✅ Easy extension
- ✅ Production deployment
